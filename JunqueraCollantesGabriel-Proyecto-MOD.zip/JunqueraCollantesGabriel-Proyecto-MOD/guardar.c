#include <stdio.h>

#include "guardar.h"

void guardUsuario(usuario *usu,int tam){
    FILE *f;
    int i=0;
    //Abrimos el fichero en forma w para que se borre todo y se cargue todo lo que haya en la memoria modificado o a�adido
    f=fopen("Usuarios.txt","w");
    //Comprobamos si el fichero se abre correctamente
    if(f==NULL){
        printf("\nNo se ha podido acceder al fichero.\n");
    }
    else{
        //Si se ha abierto correctamente, escribimos en fichero todos los elementos del vector recibido
        while(i<tam){
            fprintf(f,"%s-%s-%s-%s-%s-%s\n",usu[i].id_usuario,usu[i].nomb_usuario,usu[i].Localidad,usu[i].Perfil_usuario,usu[i].Usuario,usu[i].Contrasenna);
            i++;
        }
        printf("\nUsuarios guardados.\n");
    }
    fclose(f);
}

void guardVehiculo(coches *coche,int tam){
    FILE *f;
    int i=0;
    //Abrimos el fichero en forma w para que se borre todo y se cargue todo lo que haya en la memoria modificado o a�adido
    f=fopen("Vehiculos.txt","w");
    //Comprobamos si el fichero se abre correctamente
    if(f==NULL){
        printf("\nNo se ha podido acceder al fichero.\n");
    }
    else{
        //Si se ha abierto correctamente, escribimos en fichero todos los elementos del vector recibido
        while(i<tam){
            fprintf(f,"%s-%s-%i-%s\n",coche[i].id_mat,coche[i].id_usuario,coche[i].Num_plazas,coche[i].Desc_veh);
            i++;
        }
        printf("\nVehiculos guardados.\n");
    }
    fclose(f);
}

void guardViajes(viajes *viaj,int tam){
    FILE *f;
    int i=0;
    //Abrimos el fichero en forma w para que se borre todo y se cargue todo lo que haya en la memoria modificado o a�adido
    f=fopen("Viajes.txt","w");
    //Comprobamos si el fichero se abre correctamente
    if(f==NULL){
        printf("\nNo se ha podido acceder al fichero.\n");
    }
    else{
        //Si se ha abierto correctamente, escribimos en fichero todos los elementos del vector recibido
        while(i<tam){
            fprintf(f,"%s-%s-%i/%i/%i-%i:%i-%i:%i-%i-%s-%f-%s\n",viaj[i].id_viaje,viaj[i].id_mat,viaj[i].F_inic.dia,viaj[i].F_inic.mes,viaj[i].F_inic.anio,viaj[i].H_inic.hora,viaj[i].H_inic.minu,viaj[i].H_fin.hora,viaj[i].H_fin.minu,viaj[i].plazas_libres,viaj[i].id_vuelta,viaj[i].importe,viaj[i].estado);
            i++;
        }
        printf("\nViajes guardados.\n");
    }
    fclose(f);
}

void guardpasos(pasos *pas,int tam){
    FILE *f;
    int i=0;
    //Abrimos el fichero en forma w para que se borre todo y se cargue todo lo que haya en la memoria modificado o a�adido
    f=fopen("Pasos.txt","w");
    //Comprobamos si el fichero se abre correctamente
    if(f==NULL){
        printf("\nNo se ha podido acceder al fichero.\n");
    }
    else{
        while(i<tam){
            //Si se ha abierto correctamente, escribimos en fichero todos los elementos del vector recibido
            fprintf(f,"%s-%s\n",pas[i].id_viaje,pas[i].poblacion);
            i++;
        }
        printf("\nPasos guardados.\n");
    }
    fclose(f);
}



