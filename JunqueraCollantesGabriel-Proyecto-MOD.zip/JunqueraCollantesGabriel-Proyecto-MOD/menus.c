#include <stdio.h>

#include "menus.h"

//Menus generales

void presentacion(){
    puts("--------------------------------------------------------");
    puts("Bienvenido a la nueva aplicacion de la ESI, la ESI_SHARE");
    puts("--------------------------------------------------------");
}

int salir_aplicacion(){
    int int_salir=0;
    char salir;
    do
    {
        printf("\n\nEstas seguro que desea salir de la aplicacion?(s/n): ");
        fflush(stdin);
        scanf("%c",&salir);
        if(salir=='s'||salir=='S')
            int_salir=1;
        if(salir=='n'||salir=='N')
            int_salir=0;
        if(salir!='s'&&salir!='n'&&salir!='S'&&salir!='N')
            printf("\nEscriba una opcion valida\n");
    }
    while(salir!='s'&&salir!='n'&&salir!='S'&&salir!='N');
    return int_salir;
}

void menu_inicio_sesion(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. Iniciar sesion");
    puts("2. Crear cuenta nueva");
    puts("3. Salir de la aplicacion");
}

//Menus de usuario

void menu_perfil_usuario(){
    printf("\n\nElige la opcion que desee\n");
    puts("1. Modificar datos");
    puts("2. Volver al menu");
}

void menu_presentacion_usuario(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. Perfil");
    puts("2. Vehiculos");
    puts("3. Viajes");
    puts("4. Cerrar sesion");
}

void opciones_viaje(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. A�adir viaje");
    puts("2. Modificar viaje");
    puts("3. Unirse a un viaje");
    puts("4. Visualizar detalladamente un viaje");
    puts("5. Darse de baja de un viaje");
    puts("6. Volver al menu");
}

//Menus de administrador

void menu_presentacion_admin(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. Usuarios");
    puts("2. Vehiculos");
    puts("3. Viajes");
    puts("4. Cerrar sesion");
}

void menu_usuarios_admin(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. A�adir usuario");
    puts("2. Modificar usuario");
    puts("3. Eliminar usuario");
    puts("4. Volver al menu");
}

void menu_vehiculos_admin(){
    printf("\n\nElige la opcion que desee\n");
    puts("1. A�adir vehiculo");
    puts("2. Modificar vehiculo");
    puts("3. Eliminar vehiculo");
    puts("4. Listar todos los viajes de un vehiculo");
    puts("5. Volver al menu");
}

void menu_viajes_admin(){
    printf("\n\nElige la opcion que desee\n");
    puts("1. A�adir viaje");
    puts("2. Modificar viaje");
    puts("3. Eliminar viaje");
    puts("4. Volver al menu");
}

//Men�s compartidos

void modificacion_vehiculo(){
    printf("\n\nEscriba el numero correspondiente a lo que quieres cambiar\n");
    puts("1. Cambiar matricula");
    puts("2. Cambiar numero de plazas");
    puts("3. Cambiar descripcion");
    puts("4. Volver al menu");

}

void modificacion_usuario(){
    printf("\n\nEscriba el numero correspondiente a lo que quieres cambiar\n");
    puts("1. Cambiar nombre de usuario");
    puts("2. Cambiar la localidad");
    puts("3. Cambiar nickname");
    puts("4. Cambiar la contrase�a");
    puts("5. Volver al menu");
}

void modificacion_viaje(){
    printf("\n\nElija la opcion que desee\n");
    puts("1. Modificar fecha de inicio");
    puts("2. Modificar hora de inicio");
    puts("3. Modificar hora de llegada");
    puts("4. Modificar precio");
    puts("5. Modificar ida/vuelta");
    puts("6. Anular viaje");
    puts("7. Volver al menu");
}

void opciones_vehiculo(){
    printf("\n\nElige la opcion que desee\n");
    puts("1. A�adir vehiculo");
    puts("2. Modificar vehiculo");
    puts("3. Eliminar vehiculo");
    puts("4. Volver al menu");
}

void localidad(){
    printf("\nElige tu localidad\n");
    puts("1. Cadiz");
    puts("2. Puerto Real");
    puts("3. San Fernando");
    puts("4. Chiclana");
    puts("5. Jerez");
    puts("6. Puerto de Santa Maria");
    puts("7. Barbate");
    puts("8. Conil");
    puts("9. Rota");
    puts("10. Algeciras");
}
