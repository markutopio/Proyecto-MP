//Este modulo se encarga de guardar toda la informacion que hay en los vectores dentro de los ficheros

#ifndef guardar_h
#define guardar_h

#include "datos.h"

//Cabecera: void guardUsuario(usuario *,int)
//Precondicion: recibe un vector de tipo usuario y un entero
//Postcondicion: guarda la informacion del vector en el archivo "Usuarios.txt"
void guardUsuario(usuario *,int);


//Cabecera: void guardVehiculo(coches *,int)
//Precondicion: recibe un vector de tipo coches y un entero
//Postcondicion: guarda la informacion del vector en el archivo "Vehiculos.txt"
void guardVehiculo(coches *,int);


//Cabecera: void guardViajes(viajes *,int)
//Precondicion: recibe un vector de tipo viajes y un entero
//Postcondicion: guarda la informacion del vector en el archivo "Viajes.txt"
void guardViajes(viajes *,int);


//Cabecera: void guardpasos(pasos *,int)
//Precondicion: recibe un vector de tipo pasos y un entero
//Postcondicion: guarda la informacion del vector en el archivo "Pasos.txt"
void guardpasos(pasos *,int);

#endif // guardar_h
