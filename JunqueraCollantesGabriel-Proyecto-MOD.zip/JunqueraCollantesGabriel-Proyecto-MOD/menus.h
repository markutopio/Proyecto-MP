//Este modulo se encarga de definir y desarrollar ciertos menus que luego se van a utilizar en el main

#ifndef _MENUS_H_
#define _MENUS_H_

//Cabecera: void presentacion()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void presentacion();


//Cabecera: int salir_aplicacion()
//Precondicion: nada
//Postcondicion: devuelve 1 si se quiere salir de la aplicacion y 0 si no
int salir_aplicacion();


//Cabecera: void menu_inicio_sesion()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_inicio_sesion();


//Cabecera: void menu_perfil_usuario()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_perfil_usuario();


//Cabecera: void menu_presentacion_usuario()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_presentacion_usuario();


//Cabecera: void opciones_viaje()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void opciones_viaje();


//Cabecera: void menu_presentacion_admin()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_presentacion_admin();


//Cabecera: void menu_usuarios_admin()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_usuarios_admin();


//Cabecera: void menu_vehiculos_admin()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_vehiculos_admin();


//Cabecera: void menu_viajes_admin()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void menu_viajes_admin();


//Cabecera: void modificacion_vehiculo()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void modificacion_vehiculo();


//Cabecera: void modificacion_usuario()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void modificacion_usuario();


//Cabecera: void modificacion_viaje()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void modificacion_viaje();


//Cabecera: void opciones_vehiculo()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void opciones_vehiculo();


//Cabecera: void localidad()
//Precondicion: nada
//Postcondicion: imprime por pantalla el menu correspondiente
void localidad();

#endif // _MENUS_H_
