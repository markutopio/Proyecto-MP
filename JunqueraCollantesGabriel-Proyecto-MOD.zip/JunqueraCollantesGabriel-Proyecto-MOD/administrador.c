#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "administrador.h"

void listar_usuarios_admin(usuario *usu,int tam){
    int i;
    printf("-----------------------------------------------------------------------\n");
    printf("La lista de datos introducidos es: \n\n");
    //Recorremos todo el vector recibido y copiamos los datos por pantalla
    for(i=0;i<tam;i++){
        printf("%s-%s-%s-%s-%s-%s",usu[i].id_usuario,usu[i].nomb_usuario,usu[i].Localidad,usu[i].Perfil_usuario,usu[i].Usuario,usu[i].Contrasenna);
        printf("\n\n");
    }
    printf("\n------------------------------------------------------------------------");
}

void listar_vehiculos_admin(coches *coch, int tam_veh){
    int i;
    //Comprobamos que haya al menos un vehiculo, si no da un mensaje
    if (tam_veh > 0) {
        printf("-----------------------------------------------------------------------\n");
        printf("La lista de vehiculos es: \n\n");
        //Recorremos el vector imprimiendo los diferentes elementos
        for (i = 0; i < tam_veh; i++) {
            printf("%s-%s-%i-%s", coch[i].id_mat, coch[i].id_usuario, coch[i].Num_plazas, coch[i].Desc_veh);
            printf("\n\n");
        }
        printf("\n------------------------------------------------------------------------");
    }
    else
        printf("\nNo hay vehiculos disponibles.\n");
}

void modificar_usuario_admin(usuario *usu,int tam,int eleccion){
    char aux_nickname[6],aux_id[5];
    int encontrado,posicion,i,opcion;
    //Pedimos el id del usuario que se quiera modificar
    printf("\nIntroduce el id del usuario a modificar: ");
    fflush(stdin);
    gets(aux_id);
    //Recorremos el vector buscando el id introducido
    for(i=0;i<tam;i++)
        if(strcmp(usu[i].id_usuario,aux_id)==0){
            encontrado=1;
            posicion=i;
        }
    //Si no se ha encontrado ningun usuario con ese id, da un mensaje, si no sigue con el proceso
    if(encontrado==0)
        printf("\nNo hay ningun usuario con ese id\n");
    else{
        //la eleccion se ha desde el main, recibiendo la funcion la variable que varia
        switch(eleccion){
            case 1:
                //Modificacion de nombre
                puts("\nIntroduce el nuevo nombre de usuario: ");
                fflush(stdin);
                gets(usu[posicion].nomb_usuario);
                break;
            case 2:
                //Modificacion de localidad
                do{
                localidad();
                fflush(stdin);
                scanf("%i",&opcion);
                if(opcion>10||opcion<1)
                    printf("\nIntroduce una opcion valida\n");
                }while(opcion>10||opcion<1);
                switch(opcion){
                    case 1:
                        strcpy(usu[posicion].Localidad,"Cadiz");
                        break;
                    case 2:
                        strcpy(usu[posicion].Localidad,"Puerto Real");
                        break;
                    case 3:
                        strcpy(usu[posicion].Localidad,"San Fernando");
                        break;
                    case 4:
                        strcpy(usu[posicion].Localidad,"Chiclana");
                        break;
                    case 5:
                        strcpy(usu[posicion].Localidad,"Jerez");
                        break;
                    case 6:
                        strcpy(usu[posicion].Localidad,"Puerto Santa Maria");
                        break;
                    case 7:
                        strcpy(usu[posicion].Localidad,"Barbate");
                        break;
                    case 8:
                        strcpy(usu[posicion].Localidad,"Conil");
                        break;
                    case 9:
                        strcpy(usu[posicion].Localidad,"Rota");
                        break;
                    case 10:
                        strcpy(usu[posicion].Localidad,"Algeciras");
                        break;
                }
                break;
            case 3:
                //Modificacion de nickname
                do{
                    puts("\nIntroduce el nuevo nickname: ");
                    fflush(stdin);
                    gets(aux_nickname);
                    //Comprobamos que ese nickname no existe
                    if(comprobar_nickname(usu,tam,aux_nickname)==1)
                        printf("\nEse usuario ya existe. Prueba con otro");
                }while(comprobar_nickname(usu,tam,aux_nickname)==1);
                strcpy(usu[posicion].Usuario,aux_nickname);
                break;
            case 4:
                //Modificacion contrase�a
                puts("\nIntroduce la nueva contrasenna: ");
                fflush(stdin);
                gets(usu[posicion].Contrasenna);
                break;
        }
        printf("\nUsuario modificado con exito\n");
    }
}

void modificar_vehiculo_admin(coches *coch,int tam,int eleccion){
    char mat[8],aux_mat[8];
    int posicion,i,encontrado=0,plazas,aux_int_mat;
    //Comprobamos si el tama�o del vector vehiculos es mayor que 0, si no es asi que de un mensaje y no realice ninguna intruccion de modificacion
    if(tam>0){
        //Pedimos la matricula del vehiculo que se quiere modificar
        printf("\nIntroduce la matricula del vehiculo a modificar: ");
        fflush(stdin);
        gets(mat);
        //Recorremos el vector buscando si esa matricula existe
        for(i=0;i<tam;i++)
            if(strcmp(coch[i].id_mat,mat)==0){
                encontrado=1;
                posicion=i;
            }
        //Si se ha encontrado esa matricula se realizan las modificaciones indicadas
        if(encontrado==1){
            //El switch se realiza sobre la eleccion procedente del main
            switch(eleccion){
                case 1:
                    //Cambio de matricula
                    do{
                        aux_int_mat=0;
                        puts("\nIntroduce la nueva matricula: ");
                        fflush(stdin);
                        gets(aux_mat);
                        //Comprobamos que esa matricula no existe ya
                        aux_int_mat=comprobar_coche(coch,tam,aux_mat);
                        if(aux_int_mat==1)
                            printf("\nMatricula ya existente\n");
                    }while(aux_int_mat==1);
                    strcpy(coch[posicion].id_mat,aux_mat);
                    break;
                case 2:
                    //Cambio del numero de plazas
                    do{
                        printf("\nIntroduce el nuevo numero de plazas (sin contar la del conductor): ");
                        fflush(stdin);
                        scanf("%i",&plazas);
                    }while(plazas<1||plazas>=10);
                    coch[posicion].Num_plazas=plazas;
                    break;
                case 3:
                    //Cambio de la descripcion
                    puts("\nIntroduce la nueva descripcion (50 caracteres maximo): ");
                    fflush(stdin);
                    gets(coch[posicion].Desc_veh);
                    break;
            }
            printf("\nVehiculo modificado con exito\n");
        }
        else
            printf("\nNo hay un vehiculo con esa matricula\n");
    }
    else
        printf("\nNo hay vehiculos registrados\n");
}

void borrarUsuario_admin(usuario **usu, int *tam) {
    char opcion,aux_id[5];
    int encontrado=0,pos,i,tamaux=0;
    //Pedimos el id del usuario a eliminar
    printf("\nIntroduce el id del usuario que quieras eliminar: ");
    fflush(stdin);
    gets(aux_id);
    //Comprobamos que ese id existe en el vector de usuarios
    for(i=0;i<*tam;i++){
        if(strcmp((*usu)[i].id_usuario,aux_id)==0){
            encontrado=1;
            pos=i;
        }
    }
    //Si no se ha encontrado pondra el mensaje correspondiente, si no seguira con la eliminacion
    if(encontrado==0)
        printf("\nNo hay ningun usuario con ese id\n");
    else{
        printf("\nEstas seguro que quieres borrar el usuario con nombre %s: (S/N) ",(*usu)[pos].nomb_usuario);
        fflush(stdin);
        scanf("%c",&opcion);
        if(opcion=='s'||opcion=='S'){
            //Creamos un vector auxiliar del mismo tipo para poder copiar todo lo que no queremos eliminar
            usuario *aux;
            //Reservamos memoria dinamica para el vector auxiliar, en concreto para un elemento del tipo usuario
            aux=malloc(sizeof(usuario));
            //Recorremos el vector de usuarios copiando en el auxiliar todo lo que no queremos eliminar
            for(i=0;i<(*tam);i++){
                if(i!=pos){
                    aux[tamaux]=(*usu)[i];
                    tamaux++;
                    //Vamos aumentando el tama�o del vector auxiliar
                    aux=realloc(aux,(tamaux+1)*sizeof(usuario));
                }
            }
            //Actualizamos el tama�o del vector que recibimos
            (*tam)=tamaux;
            free(*usu);
            //Reservamos memoria dinamica para el vector de usuarios recibido con un tama�o igual al que tiene el auxiliar, que es donde estan los elementos que no queremos eliminar
            *usu=malloc((*tam)*sizeof(usuario));
            //Copiamos los elementos del auxiliar en el recibido
            (*usu)=aux;
            //Le hacemos un aumento de memoria en el vector de un elemento mas para futuras actualizaciones
            *usu=realloc(*usu,((*tam)+1)*sizeof(usuario));
            printf("\nUsuario eliminado\n");
        }
        else {
            printf("\nOperacion abortada\n");
        }
    }
}

void borrarVehiculo_admin(coches **veh, int *tam) {
    char opcion,aux_mat[8];
    int encontrado=0,i,tamaux=0;
    //Comprobamos que hay al menos un vehiculo, si no directamente dara un mensaje por pantalla
    if(*tam>0){
        //Pedimos la matricula del vehiculo que se quiera eliminar
        printf("\nIntroduce la matricula del vehiculo que quieras eliminar: ");
        fflush(stdin);
        gets(aux_mat);
        //Recorremos el vector de vehiculos para ver si esa matricula existe
        for(i=0;i<(*tam);i++)
            if(strcmp((*veh)[i].id_mat,aux_mat)==0)
                encontrado=1;
        //Si se ha encontrado, entonces se sigue con el proceso, si no dara un mensaje por pantalla y terminara
        if(encontrado==1){
            printf("\nEstas seguro que quieres borrar el vehiculo: (S/N) ");
            fflush(stdin);
            scanf("%c",&opcion);
            if(opcion=='s'||opcion=='S'){
                //Creamos un auxiliar del mismo tipo para copiar en el todos los elementos del vector que no se quieran eliminar
                coches *aux;
                //Reservamos memoria dinamica para el vector aux de un elementos del tipo coches
                aux=malloc(sizeof(coches));
                for(i=0;i<(*tam);i++){
                    //Mientras no coincida la matricula con la introducida, se copia la informacion en el auxiliar
                    if(strcmp((*veh)[i].id_mat,aux_mat)!=0){
                        aux[tamaux]=(*veh)[i];
                        tamaux++;
                        aux=realloc(aux,(tamaux+1)*sizeof(coches));
                    }
                }
                //Actualizamos el tama�o del vector recibido
                (*tam)=tamaux;
                free(*veh);
                //Reservamos memoria dinamica para el vector recibido de tantos elementos como tenga el auxiliar
                *veh=malloc((*tam)*sizeof(coches));
                //Copiamos los elementos del auxiliar en el recibido
                (*veh)=aux;
                //Aumento de memoria para posibles actualizaciones futuras
                *veh=realloc(*veh,((*tam)+1)*sizeof(coches));
                printf("\nVehiculo eliminado\n");
            }
            else
                printf("\nOperacion abortada\n");
        }
        else
            printf("\nNo existen vehiculos con esa matricula\n");
    }
    else
        printf("\nNo hay vehiculos registrados");
}

void borrarViaje_admin(coches *coch,viajes **viaj, int *tam,int tam_coches, char *aux_id){
    char opcion,aux_mat[8];
    int i,encontrado,posicion,pos_mat;
    //Comprobamos que el tama�o del vector es mayor que 0, si no terminara dando un mensaje por pantalla
    if(*tam>0){
        //Pedimos el id del viaje a eliminar
        printf("\nIntroduce el id del viaje que quieras eliminar: ");
        fflush(stdin);
        gets(aux_id);
        //Comprobamos que ese id existe y salvaguardamos su posicion en una variable y la matricula asociada en otra
        for(i=0;i<(*tam);i++)
            if(strcmp((*viaj)[i].id_viaje,aux_id)==0){
                 encontrado=1;
                 posicion=i;
                 strcpy(aux_mat,(*viaj)[i].id_mat);
            }
        //Recorremos el vector de vehiculos y si coincide la matricula que hemos salvaguardado con la del elemento del vector, guardamos la posicion del vehiculo en otra variable
        for(i=0;i<tam_coches;i++)
            if(strcmp(coch[i].id_mat,aux_mat)==0)
                pos_mat=i;
        //Comprobamos que se ha encontrado ese id, y que el numero de plazas libres es igual al definidio en el vehiculo, requisito para poder eliminar un viaje
        if(encontrado==1&&(*viaj)[posicion].plazas_libres==coch[pos_mat].Num_plazas){
            printf("\nEstas seguro que quieres borrar el viaje: (S/N) ");
            fflush(stdin);
            scanf("%c",&opcion);
            if(opcion=='s'||opcion=='S'){
                //Hacemos uso de un auxiliar del mismo tipo para poder meter en el todos los elementos que no queramos eliminar
                viajes *aux;
                int tamaux=0,i;
                //Reservamos memoria dinamica para el auxiliar (1 elemento)
                aux=malloc(sizeof(viajes));
                for(i=0;i<(*tam);i++){
                    //Mientras no coincida el id del viaje introducido con el del elemento que comprobamos del vector, se copia en el auxiliar el viaje
                    if(strcmp((*viaj)[i].id_viaje,aux_id)!=0){
                        aux[tamaux]=(*viaj)[i];
                        tamaux++;
                        //Aumentamos en 1 la reserva de memoria para el auxiliar
                        aux = realloc(aux, (tamaux + 1) * sizeof(viajes));
                    }
                }
                //Actualizamos el tama�o del vector recibido
                (*tam)=tamaux;
                free(*viaj);
                //Reservamos memoria para el vector recibido con un tama�o igual al del auxiliar
                *viaj=malloc((*tam)*sizeof(viajes));
                //Copiamos los elementos del auxiliar en el recibido
                (*viaj)=aux;
                //Aumentamos en 1 elementos la reserva de memoria del recibido para posibles actualizaciones futuras
                *viaj=realloc(*viaj,((*tam)+1)*sizeof(viajes));
                printf("\nViaje eliminado\n");
            }
            else
                printf("\nOperacion abortada\n");
        }
        else
            printf("\nEse identificador de viaje no existe o no se puede borrar el viaje al haber gente registrada\n");
    }
    else
        printf("\nNo hay viajes disponibles\n");
}

void borrarPasos_admin(pasos **pas, int *tam, char *id){
    //Creamos un auxiliar del mismo tipo para meter en el todo lo que no queramos eliminar
    pasos *aux;
    int tamaux=0;
    int i;
    //Reservamos memoria dinamica para el vector auxiliar (1 elemento)
    aux=malloc(sizeof(pasos));
    for(i=0;i<(*tam);i++)
        //Si no coincide el id del viaje con el id que recibe la funcion, se copiara en el auxiliar
        if(strcmp((*pas)[i].id_viaje,id)!=0){
            aux[tamaux]=(*pas)[i];
            tamaux++;
            //Aumentamos en 1 la reserva de memoria para el auxiliar
            aux=realloc(aux,(tamaux+1)*sizeof(pasos));
        }
    //Actualizamos el tama�o del vector recibido
    (*tam)=tamaux;
    free(*pas);
    //Reservamos memoria dinamica para el vector recibido con el mismo tama�o que el vector auxiliar
    *pas=malloc((*tam)*sizeof(pasos));
    //Copiamos los elementos del auxiliar en el recibido
    (*pas)=aux;
    //Realizamos un aumento de memoria para posibles actualizaciones futuras
    *pas=realloc(*pas,((*tam)+1)*sizeof(pasos));
}


void modificar_viajes_admin(coches *coch,viajes *viaj,int tam_viaj,int tam_coch,int eleccion){
    char aux_id[7],opcion[7],dia[3],mes[3],anio[5],hora[3],minuto[3],aux_hora[3],aux_min[3];
    int i,j,correcto=0,encontrado=0;
    //Comprobamos que el tama�o del vector es mayor que 0, si no dara un mensaje directamente y terminara
    if(tam_viaj>0){
        //Pedimos el id del viaje
        printf("\nIntroduce el id del viaje: ");
        fflush(stdin);
        gets(aux_id);
        //Comprobamos que ese id exista, y que el numero de plazas libres sea el mismo que el especificado al crear el vehiculo, requisito para modificar un viaje
        for(j=0;j<tam_viaj;j++)
            if(strcmp(viaj[j].id_viaje,aux_id)==0)
                for(i=0;i<tam_coch;i++)
                    if(strcmp(coch[i].id_mat,viaj[j].id_mat)==0)
                        if(viaj[j].plazas_libres==coch[i].Num_plazas){
                            //Si se ha encontrado, salvaguardamos la informacion metiendo un 1 en la variable encontrado
                            encontrado=1;
                            switch(eleccion){
                                case 1:
                                    //Modificacion de la fecha
                                    do{
                                        correcto=0;
                                        printf("\nIntroduzca el d�a del viaje en formato DD: ");
                                        fflush(stdin);
                                        scanf("%s",dia);
                                        printf("\nIntroduzca el mes en formato MM: ");
                                        fflush(stdin);
                                        scanf("%s",mes);
                                        printf("\nIntroduzca el a�o en formato AAAA: ");
                                        fflush(stdin);
                                        scanf("%s",anio);
                                        //Comprobamos si la fecha introducida es correcta, haciendo diferenciacion entre si es laactual o no
                                        //Si la fecha es la actual, tendremos que comprobar que las horas almacenadas se ajustan a la actual
                                        if(comprobarFecha(dia,mes,anio)==1){
                                            //Pasamos de entero a cadena para poder pasar los parametros a la funcion de a continuacion
                                            sprintf(hora,"%i",viaj[j].H_inic.hora);
                                            sprintf(minuto,"%i",viaj[j].H_inic.minu);
                                            //Comprobamos que la hora de inicio no haya pasado, en ese caso, almacenamos la fecha
                                            if(comprobarHora_actual(hora,minuto)==1){
                                                //Pasamos de cadena a entero para poder pasarselo a la funcion
                                                viaj[j].F_inic.dia=atoi(dia);
                                                viaj[j].F_inic.mes=atoi(mes);
                                                viaj[j].F_inic.anio=atoi(anio);
                                                correcto=1;
                                            }
                                            //Si ha pasado, comprobamos si la final aun no ha pasado, en ese caso almacenamos tambien la fecha
                                            else{
                                                //Pasamos de entero a cadena para poder pasarselo a la funcion
                                                sprintf(hora,"%i",viaj[j].H_fin.hora);
                                                sprintf(minuto,"%i",viaj[j].H_fin.minu);
                                                if(comprobarHora_actual(hora,minuto)==1){
                                                    //Pasamos de cadena a entero para poder almacenarlo en el vector
                                                    viaj[j].F_inic.dia=atoi(dia);
                                                    viaj[j].F_inic.mes=atoi(mes);
                                                    viaj[j].F_inic.anio=atoi(anio);
                                                    correcto=1;
                                                }
                                            }
                                        }
                                        //Si la fecha no es la de hoy, independientemente de la hora, almacenamos la nueva
                                        if(comprobarFecha(dia,mes,anio)==2){
                                            viaj[j].F_inic.dia=atoi(dia);
                                            viaj[j].F_inic.mes=atoi(mes);
                                            viaj[j].F_inic.anio=atoi(anio);
                                            correcto=1;
                                        }
                                        //Si la fecha no es correcta o ya ha pasado, o es la actual pero las horas que habia metidas ya han pasado, que de un mensaje y repita el bucle
                                        if(correcto==0)
                                            printf("\nIntroduce una fecha valida y acorde a la actual (si la fecha es la actual la hora tambien debe estar correcta)\n");
                                    }while(correcto==0);
                                    break;
                                case 2:
                                    //Modificacion de la hora de inicio
                                    //Pasamos de entero (lo que haya en la estructura) a cadena para la funcion
                                    sprintf(dia,"%i",viaj[j].F_inic.dia);
                                    sprintf(mes,"%i",viaj[j].F_inic.mes);
                                    sprintf(anio,"%i",viaj[j].F_inic.anio);
                                    //Si la fecha es la actual, entonces comprueba la hora con la actual
                                    if(comprobarFecha(dia,mes,anio)==1){
                                        do{
                                            correcto=0;
                                            printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
                                            fflush(stdin);
                                            scanf("%s",hora);
                                            printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
                                            fflush(stdin);
                                            scanf("%s",minuto);
                                            //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                            sprintf(aux_hora,"%i",viaj[j].H_fin.hora);
                                            sprintf(aux_min,"%i",viaj[j].H_fin.minu);
                                            //Comprobamos que la hora de llegada es posterior a la de inicio introducida
                                            if(comprobar_hora2_menor_hora1(hora,minuto,aux_hora,aux_min)==1){
                                                //Comprobamos si la hora es correcta con respecto a la actual
                                                correcto=comprobarHora_actual(hora,minuto);
                                                if(correcto==0)
                                                    printf("\nIntroduce una hora valida y acorde a la actual\n");
                                            }
                                            else
                                                printf("\nLa hora de inicio no tiene sentido respecto de la de finalizacion\n");
                                        }while(correcto!=1);
                                        //Pasamos de cadena a entero para almacenar en vector
                                        viaj[j].H_inic.minu=atoi(minuto);
                                        viaj[j].H_inic.hora=atoi(hora);
                                    }
                                    //Si no es la actual, debe comprobar la hora sin tener en cuenta la actual
                                    else{
                                        do{
                                            correcto=0;
                                            printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
                                            fflush(stdin);
                                            scanf("%s",hora);
                                            printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
                                            fflush(stdin);
                                            scanf("%s",minuto);
                                            //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                            sprintf(aux_hora,"%i",viaj[j].H_fin.hora);
                                            sprintf(aux_min,"%i",viaj[j].H_fin.minu);
                                            //Comprobamos que la hora de llegada es posterior a la de inicio introducida
                                            if(comprobar_hora2_menor_hora1(hora,minuto,aux_hora,aux_min)==1){
                                                //Comprobamos si la hora es correcta con respecto a la actual
                                                correcto=comprobar_hora(hora,minuto);
                                                if(correcto==0)
                                                    printf("\nIntroduce una hora valida y acorde a la actual\n");
                                            }
                                            else
                                                printf("\nLa hora de inicio no tiene sentido respecto de la de finalizacion\n");
                                        }while(correcto!=1);
                                        //Pasamos de cadena a entero para almacenar en vector
                                        viaj[j].H_inic.minu=atoi(minuto);
                                        viaj[j].H_inic.hora=atoi(hora);
                                    }
                                    break;
                                case 3:
                                    //Modificacion de la hora de llegada
                                    //Pasamos de entero (lo que haya en la estructura) a cadena para la funcion
                                    sprintf(dia,"%i",viaj[j].F_inic.dia);
                                    sprintf(mes,"%i",viaj[j].F_inic.mes);
                                    sprintf(anio,"%i",viaj[j].F_inic.anio);
                                    //Si la fecha es la actual, entonces comprueba la hora con la actual
                                    if(comprobarFecha(dia,mes,anio)==1){
                                        do{
                                            correcto=0;
                                            printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
                                            fflush(stdin);
                                            scanf("%s",hora);
                                            printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
                                            fflush(stdin);
                                            scanf("%s",minuto);
                                            //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                            sprintf(aux_hora,"%i",viaj[j].H_inic.hora);
                                            sprintf(aux_min,"%i",viaj[j].H_inic.minu);
                                            //Comprobamos que la hora de llegada introducida es posterior a la de inicio
                                            if(comprobar_hora2_menor_hora1(aux_hora,aux_min,hora,minuto)==1){
                                                //Comprobamos si la hora es correcta con respecto a la actual
                                                correcto=comprobarHora_actual(hora,minuto);
                                                if(correcto==0)
                                                    printf("\nIntroduce una hora valida y acorde a la actual\n");
                                            }
                                            else
                                                printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
                                        }while(correcto!=1);
                                        //Pasamos de cadena a entero para almacenar en vector
                                        viaj[j].H_fin.minu=atoi(minuto);
                                        viaj[j].H_fin.hora=atoi(hora);
                                    }
                                    //Si no es la actual, debe comprobar la hora sin tener en cuenta la actual
                                    else{
                                        do{
                                            correcto=0;
                                            printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
                                            fflush(stdin);
                                            scanf("%s",hora);
                                            printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
                                            fflush(stdin);
                                            scanf("%s",minuto);
                                            //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                            sprintf(aux_hora,"%i",viaj[j].H_inic.hora);
                                            sprintf(aux_min,"%i",viaj[j].H_inic.minu);
                                            //Comprobamos que la hora de llegada introducida es posterior a la de inicio
                                            if(comprobar_hora2_menor_hora1(aux_hora,aux_min,hora,minuto)==1){
                                                //Comprobamos si la hora es correcta con respecto a la actual
                                                correcto=comprobar_hora(hora,minuto);
                                                if(correcto==0)
                                                    printf("\nIntroduce una hora valida y acorde a la actual\n");
                                            }
                                            else
                                                printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
                                        }while(correcto!=1);
                                        //Pasamos de cadena a entero para almacenar en vector
                                        viaj[j].H_fin.minu=atoi(minuto);
                                        viaj[j].H_fin.hora=atoi(hora);
                                    }
                                    break;
                                case 4:
                                    //Modificacion del importe
                                    printf("\nIntroduce el nuevo importe: ");
                                    scanf("%f",&viaj[j].importe);
                                    break;
                                case 5:
                                    do{
                                        correcto=0;
                                        printf("\nIntroduce si el viaje es de ida o de vuelta (poner ida o vuelta): ");
                                        fflush(stdin);
                                        gets(opcion);
                                        //Si la palabra introducida no es ida o vuelta seguira pidiendola
                                        if(strcmp(opcion,"ida")!=0&&strcmp(opcion,"vuelta")!=0){
                                            printf("\nPalabra introducida incorrecta. Escribela tal y como aparece en la reclamacion del dato\n");
                                            correcto=1;
                                        }
                                    }while(correcto==1);
                                    strcpy(viaj[j].id_vuelta,opcion);
                                    break;
                                case 6:
                                    //Como que llegue aqui significa que no se ha apuntado nadie al viaje, entonces podemos ponder anulado directamente
                                    strcpy(viaj[j].estado,"anulado");
                                    break;
                        }
                        printf("\nViaje modificado con exito\n");
                    }
        //Si no se ha encontrado, que de un mensaje por pantalla
        if(encontrado==0)
            printf("\nNo se puede modificar ya que no existe un viaje con ese id o porque ya hay gente apuntada a el\n");
    }
    else
        printf("\nNo existen viajes disponibles para modificar\n");
}
