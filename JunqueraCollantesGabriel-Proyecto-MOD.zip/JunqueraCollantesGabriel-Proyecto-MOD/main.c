#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "main.h"
//P�gina principal

int main(){
    presentacion();
    //Cargamos todo lo que haya en los ficheros sobre los vectores
    cargarUsuario(&vectUsuarios,&numUsuarios);
    cargarVehiculo(&vectVehiculos,&numVehiculos);
    cargarViajes(&vectViajes,&numViajes);
    cargarPasos(&vectPasos,&numPasos);
    //Realizamos las comprobaciones de la hora para actualizar el estado de los viajes
    comprobaciones_iniciales(vectViajes,numViajes);
    //Llamamos a inicio de sesion
    inicio_sesion();
    return 0;
}

void inicio_sesion(){
    int opcion;
    menu_inicio_sesion();
    do{
        fflush(stdin);
        scanf("%i",&opcion);
        if(opcion<1||opcion>3)
            printf("\nIntroduce una opcion valida\n");
    }while(opcion<1||opcion>3);
    switch(opcion){
        case 1:
            if(login(vectUsuarios,numUsuarios,&posusu)==1){
                //Si login devuelve 1 (se ha logeado correctamente) y comprobar admin devuelve 1 (es admin), iremos al menu de admin
                if(comprobar_admin(vectUsuarios,posusu)==1)
                    opciones_presentacion_admin();
                //Si login devuelve 1 pero no es admin, nos lleva al menu de usuario
                else
                    opciones_presentacion_usuario();
            }
            //Si no se ha logeado correctamente, volvemos a llamar a inicio_sesion
            else
                inicio_sesion();
            break;
        case 2:
            //Opcion de crear usuarios
            vectUsuarios=crearUsuario(vectUsuarios,&numUsuarios);
            inicio_sesion();
            break;

        case 3:
            //Si la funcion salir_aplicacion devuelve 1, entonces se desea salir de la misma y guardamos todo en los ficheros
            if(salir_aplicacion()==1){
                guardUsuario(vectUsuarios,numUsuarios);
                guardVehiculo(vectVehiculos,numVehiculos);
                guardViajes(vectViajes,numViajes);
                guardpasos(vectPasos,numPasos);
                exit(-1);
            }
            else
                inicio_sesion();
            break;
    }
}

void opciones_presentacion_usuario(){
    char aux_id_usuario[5],aux_mat[8],aux_id_viaj[7],aux_localidad[21];
    int eleccion,opcion,aux_plazas;
    menu_presentacion_usuario();
    do{
        fflush(stdin);
        scanf("%i",&opcion);
        if(opcion<1||opcion>4)
            printf("\nIntroduce una opcion valida\n");
    }while(opcion<1||opcion>4);
    //Copiamos el id del usuario que esta logeado en un auxiliar para usos futuros en otras funciones
    strcpy(aux_id_usuario,vectUsuarios[posusu].id_usuario);
    switch(opcion){
        case 1:
            //Opcion usuarios
            //Listamos la informacion del usuario logeado
            listar_usuarios(vectUsuarios,numUsuarios,posusu);
            menu_perfil_usuario();
            do{
                fflush(stdin);
                scanf("%i",&eleccion);
                if(eleccion<1||eleccion>2)
                    printf("\nIntroduce una opcion valida\n");
            }while(eleccion<1||eleccion>2);

            switch(eleccion){
                case 1:
                    //Modificacion del usuario
                    modificacion_usuario();
                    do{
                        fflush(stdin);
                        scanf("%i",&eleccion);
                        if(eleccion<1||eleccion>5)
                            printf("\nIntroduce una opcion valida\n");
                    }while(eleccion<1||eleccion>5);
                    //Si la eleccion es 5, se ira de nuevo a opciones_presentacion_usuario, si no se llamara a modificar
                    if(eleccion!=5)
                        modificar_usuario(vectUsuarios,numUsuarios,posusu,eleccion);
                    break;
                case 2:
                    //Volver atras (no ponemos nada pues despues del switch va a ese menu)
                    break;
            }
            opciones_presentacion_usuario();
            break;
        case 2:
            //Opcion vehiculos
            //Listamos los vehiculos asociados al usuario
            listar_vehiculos(vectVehiculos,numVehiculos,aux_id_usuario);
            opciones_vehiculo();
            do{
                fflush(stdin);
                scanf("%i",&eleccion);
                if(eleccion<1||eleccion>4)
                    printf("\nIntroduce una opcion valida\n");
            }while(eleccion<1||eleccion>4);
            switch(eleccion){
                case 1:
                    //Crear vehiculos
                    vectVehiculos=crearVehiculo(vectVehiculos,&numVehiculos,aux_id_usuario);
                    break;
                case 2:
                    //Modificar vehiculos
                    modificacion_vehiculo();
                    do{
                        fflush(stdin);
                        scanf("%i",&eleccion);
                        if(eleccion>4||eleccion<1)
                            printf("\nIntroduce una opcion valida\n");
                    }while(eleccion>4||eleccion<1);
                    //Si la eleccion es 4 significa volver al menu, si no que nos lleve a modificar vehiculo
                    if(eleccion!=4)
                        modificar_vehiculo(vectVehiculos,numVehiculos,aux_id_usuario,eleccion);
                    break;
                case 3:
                    //Borrar vehiculo
                    borrarVehiculo(&vectVehiculos,&numVehiculos,aux_id_usuario);
                    break;
                case 4:
                    //Volver al menu (no ponemos nada porque despues del switch vuelve al menu)
                    break;
                }
            opciones_presentacion_usuario();
            break;
        case 3:
            //Opcion viajes
            //Listamos todos los viajes presentes en el sistema
            listar_viajes(vectViajes,numViajes);
            opciones_viaje();
            fflush(stdin);
            do{
                fflush(stdin);
                scanf("%i",&opcion);
                if(opcion<1||opcion>6)
                    printf("\nIntroduce una opcion valida\n");
            }while(opcion<1||opcion>6);
            switch(opcion){
                case 1:
                    //Crear viajes
                    //Comprobamos que el usuario tenga vehiculos asociados
                    if(comprobar_vehiculos_asociado(vectVehiculos,numVehiculos,aux_id_usuario)==1)
                        //Comprobamos que la matricula que introduce (en la funcion y que recibe el main) esta asociada a su id
                        if(comprobar_matricula_id(vectVehiculos,numVehiculos,aux_id_usuario,aux_mat,&aux_plazas)==1){
                            vectViajes=crearViajes(vectViajes,&numViajes,aux_mat,aux_plazas,aux_id_viaj);
                            //Creamos pasos asociados a ese viaje
                            vectPasos=crearPasos(vectPasos,&numPasos,aux_id_viaj);
                        }
                    break;
                case 2:
                    //Modificar viaje
                    modificacion_viaje();
                    do{
                        fflush(stdin);
                        scanf("%i",&eleccion);
                        if(eleccion>7||eleccion<1)
                            printf("\nIntroduce una opcion valida\n");
                    }while(eleccion>7||eleccion<1);
                    //Si la eleccion es 7 seria volver al menu, si no que nos lleve a modificar_viajes
                    if(eleccion!=7)
                        modificar_viajes(vectVehiculos,vectViajes,numViajes,numVehiculos,aux_id_usuario,eleccion);
                    break;
                case 3:
                    //Unirse a un viaje
                    //Copiamos en un auciliar la localidad del usuario para pasarla a la funcion unirse_viaje
                    strcpy(aux_localidad,vectUsuarios[posusu].Localidad);
                    unirse_viaje(vectViajes,vectPasos,vectVehiculos,numViajes,numPasos,numVehiculos,aux_localidad);
                    break;
                case 4:
                    //Listar un viaje de forma detallada
                    listar_viajes_detallado(vectViajes,vectPasos,numViajes,numPasos);
                    break;
                case 5:
                    //Darse de baja de un viaje
                    darse_baja_viaje(vectViajes,vectVehiculos,numViajes,numVehiculos);
                    break;
                case 6:
                    //Volver al menu (no ponemos nada porque despues del switch se vuelve al menu)
                    break;
            }
            opciones_presentacion_usuario();
            break;
        case 4:
            //Cerrar sesion
            inicio_sesion();
            break;
    }
}

void opciones_presentacion_admin(){
    char aux_id_usu[5],aux_mat[8],aux_id_viaj[7];
    int opcion,opcion_mod,eleccion,aux_plazas;
    menu_presentacion_admin();
    do{
        fflush(stdin);
        scanf("%i",&opcion);
        if(opcion<1||opcion>4)
            printf("\nIntroduce una opcion valida\n");
    }while(opcion<1||opcion>4);
    //Copiamos en un auxiliar la posicion del administrador en el vector para posibles usos futuros
    strcpy(aux_id_usu,vectUsuarios[posusu].id_usuario);
    switch(opcion){
        case 1:
            //Usuarios
            //Listamos todos los usuarios presentes en el sistema
            listar_usuarios_admin(vectUsuarios,numUsuarios);
            menu_usuarios_admin();
            do{
                fflush(stdin);
                scanf("%i",&eleccion);
                if(eleccion<1||eleccion>4)
                    printf("\nIntroduce una opcion valida\n");
            }while(eleccion<1||eleccion>4);
            switch(eleccion){
                case 1:
                    //Crear usuario
                    vectUsuarios=crearUsuario(vectUsuarios,&numUsuarios);
                    break;
                case 2:
                    //Modificar usuario
                    modificacion_usuario();
                    do{
                        fflush(stdin);
                        scanf("%i",&opcion_mod);
                        if(opcion_mod>5||opcion_mod<1)
                            printf("\nIntroduce una opcion valida\n");
                    }while(opcion_mod>5||opcion_mod<1);
                    //Si es 5 seria volver al menu, por lo que nos llevara a modificar_usuario_admin cuando sea distinto de 5
                    if(opcion_mod!=5)
                        modificar_usuario_admin(vectUsuarios,numUsuarios,opcion_mod);
                    break;
                case 3:
                    //Borrar usuario
                    borrarUsuario_admin(&vectUsuarios,&numUsuarios);
                    break;
                case 4:
                    //Volver al menu (no ponemos nada porque despues del switch se llama de nuevo al menu)
                    break;
            }
            opciones_presentacion_admin();
            break;
        case 2:
            //Vehiculos
            //Listamos todos los vehiculos
            listar_vehiculos_admin(vectVehiculos,numVehiculos);
            menu_vehiculos_admin();
            do{
                fflush(stdin);
                scanf("%i",&eleccion);
                if(eleccion<1||eleccion>5)
                    printf("\nIntroduce una opcion valida\n");
            }while(eleccion<1||eleccion>5);
            switch(eleccion){
                case 1:
                    //Crear vehiculos
                    vectVehiculos=crearVehiculo(vectVehiculos,&numVehiculos,aux_id_usu);
                    break;
                case 2:
                    //Modificar vehiculos
                    modificacion_vehiculo();
                    do{
                        fflush(stdin);
                        scanf("%i",&opcion_mod);
                        if(opcion_mod>4||opcion_mod<1)
                            printf("\nIntroduce una opcion valida\n");
                    }while(opcion_mod>4||opcion_mod<1);
                    //Si la opcion es 4 es volver al menu, luego llamara a modificar_vehiculo_admin cuando sea distinto de 4
                    if(opcion_mod!=4)
                        modificar_vehiculo_admin(vectVehiculos,numVehiculos,opcion_mod);
                    break;
                case 3:
                    //Borrar vehiculo
                    borrarVehiculo_admin(&vectVehiculos,&numVehiculos);
                    break;
                case 4:
                    //Listar todos los viajes de un vehiculo
                    listar_viajes_vehiculo(vectViajes,numViajes);
                    break;
                case 5:
                    //Volver al menu (no ponemos nada porque despues del switch se vuelve al menu)
                    break;
            }
            opciones_presentacion_admin();
            break;
        case 3:
            //Viajes
            //Listamos todos los viajes que haya en el sistema
            listar_viajes(vectViajes,numViajes);
            menu_viajes_admin();
            do{
                fflush(stdin);
                scanf("%i",&eleccion);
                if(eleccion<1||eleccion>4)
                    printf("\nIntroduce una opcion valida\n");
            }while(eleccion<1||eleccion>4);
            switch(eleccion){
                case 1:
                    //Comprobamos que el administrador tenga vehiculos asociados
                    if(comprobar_vehiculos_asociado(vectVehiculos,numVehiculos,aux_id_usu)==1)
                        //Comprobamos que la matricula que introduce (en la funcion y que recibe el main) esta asociada a su id
                        if(comprobar_matricula_id(vectVehiculos,numVehiculos,aux_id_usu,aux_mat,&aux_plazas)==1){
                            vectViajes=crearViajes(vectViajes,&numViajes,aux_mat,aux_plazas,aux_id_viaj);
                            //Creamos los pasos asociados al id del viaje
                            vectPasos=crearPasos(vectPasos,&numPasos,aux_id_viaj);
                        }
                    break;
                case 2:
                    //Modificar viaje
                    modificacion_viaje();
                    do{
                        fflush(stdin);
                        scanf("%i",&opcion_mod);
                        if(opcion_mod>7||opcion_mod<1)
                            printf("\nIntroduce una opcion valida\n");
                    }while(opcion_mod>7||opcion_mod<1);
                    //Si la opcion es 7 es volver al menu, luego llamara a modificar_vehiculo_admin cuando sea distinto de 4
                    if(opcion_mod!=7)
                        modificar_viajes_admin(vectVehiculos,vectViajes,numViajes,numVehiculos,opcion_mod);
                    break;
                case 3:
                    //Borrar viaje
                    borrarViaje_admin(vectVehiculos,&vectViajes,&numViajes,numVehiculos,aux_id_viaj);
                    //Borramos los pasos asociados al viaje borrado
                    borrarPasos_admin(&vectPasos,&numPasos,aux_id_viaj);
                    break;
                case 4:
                    //Volver al menu (no ponemos nada porque despues del switch se vuelve al menu)
                    break;
            }
            opciones_presentacion_admin();
            break;
        case 4:
            //Cerrar sesion
            inicio_sesion();
            break;
    }
}
