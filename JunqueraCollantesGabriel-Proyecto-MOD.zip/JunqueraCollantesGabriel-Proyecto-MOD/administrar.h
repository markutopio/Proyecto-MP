//Este modulo se encarga de diversas funciones necesarias para el correcto funcionamiento del programa (modificaciones, comprobaciones, creaciones...)

#ifndef _ADMINISTRAR_
#define _ADMINISTRAR_

#include "datos.h"
#include "menus.h"

//Cabecera int login(usuario *, int, char*)
//Precondicion: Recibe un vector de tipo usuario, un entero (el tama�o), y un puntero a entero
//Postcondicion: Devuelve 1 si existe y 0 si no y deja en el puntero a entero la posicion dentro del vector
int login(usuario *, int,int*);


//Cabecera: void asignar_id_usuario(usuario *,int,char*)
//Precondicion: Recibe un vector de tipo usuario, un entero (su tama�o) y una cadena de caracteres
//Postcondicion: Devuelve en la cadena de caracteres que recibe la id disponible mas baja posible
void asignar_id_usuario(usuario *,int,char*);


//Cabecera: void asignar_id_viaje(viajes *,int,char*)
//Precondicion: Recibe un vector de tipo viajes, un entero (su tama�o) y una cadena de caracteres
//Postcondicion: Devuelve en la cadena de caracteres que recibe la id disponible mas baja posible
void asignar_id_viaje(viajes *,int,char*);


//Cabecera: void listar_usuarios(usuario *,int,int)
//Precondicion: Recibe un vector de tipo usuario, y dos enteros (el tama�o del vector y la posicion en el vector del usuario que llama a la funcion)
//Postcondicion: Lista por pantalla todos los usuarios presentes en el vector
void listar_usuarios(usuario *,int,int);


//Cabecera: void listar_vehiculos(coches *,int,char*)
//Precondicion: Recibe un vector de tipo coches, un entero (tama�o del vector) y una cadena de caracteres (id del usuario que llama a la funcion);
//Postcondicion: Lista por pantalla todos los vehiculos presentes en el vector
void listar_vehiculos(coches *,int,char*);


//Cabecera: void listar_viajes(viajes *,coches *,int,int)
//Precondicion: Recibe un vector de tipo viajes y un entero (su tama�o)
//Postcondicion: Lista por pantalla todos los viajes presentes en el vector
void listar_viajes(viajes *,int);


//Cabecera: void listar_viajes_detallado(viajes *,pasos *,coches *,int,int,int)
//Precondicion: Recibe dos vectores (uno de tipo viajes y otro pasos) y dos enteros (sus tama�os)
//Postcondicion: Lista por pantalla toda la informacion relativa al id del viaje que se introduce dentro de la funcion
void listar_viajes_detallado(viajes *,pasos *,int,int);


//Cabecera: void listar_viajes_vehiculo(viajes *,int)
//Precondicion: Recibe un vector de tipo viajes y un entero (su tama�o)
//Postcondicion: Lista por pantalla todos los viajes realizados por el vehiculo cuya matricula se especifica dentro de la funcion
void listar_viajes_vehiculo(viajes *,int);


//Cabecera: int comprobar_nickname(usuario *,int,char *)
//Precondicion: Recibe un vector de tipo usuario, un entero (su tama�o), y una cadena de caracteres (un nickname)
//Postcondicion: Devuelve 1 si esa cadena ya se encuentra en el vector y 0 si no
int comprobar_nickname(usuario *,int,char *);


//Cabecera: int comprobar_admin (usuario *,int)
//Precondicion: Recibe un vector de tipo usuario y un entero (la posicion en el vector del usuario que la llama)
//Postcondicion: Devuelve 1 si es administrador
int comprobar_admin (usuario *,int);


//Cabecera: int comprobar_vehiculos_asociado(coches *,int,char *)
//Precondicion: Recibe un vector de tipo coches, un entero (su tama�o) y una cadena de caracteres (id del usuario que la llama)
//Postcondicion: Devuelve 1 si hay vehiculos asociados a ese id
int comprobar_vehiculos_asociado(coches *,int,char *);


//Cabecera: int comprobar_matricula_id(coches *,int,char *,char *,int *)
//Precondicion: Recibe un vector de tipo coches, un entero (su tama�o), dos cadenas de caracteres (siendo la primera el id del usuario que la llama) y un puntero a entero
//Postcondicion: Devuelve 1 si la matricula introducida dentro de la funcion esta asociado al id ademas de dejar en la segunda cadena que recibe la matricula y en el puntero a entero el numero de plazas
int comprobar_matricula_id(coches *coch,int,char *,char *,int *);


//Cabecera: int comprobarFecha(char *, char *, char *)
//Precondicion: Recibe tres cadenas de caracteres (dia,mes,a�o)
//Postcondicion: Devuelve 2 si es correcta pero no ha pasado, 1 si la fecha es correcta y es la de hoy y 0 si no es correcta
int comprobarFecha(char*,char*,char*);


//Cabecera: int comprobarHora_actual(char *, char *)
//Precondicion: Recibe dos cadenas de caracteres (hora,minutos)
//Postcondicion: Devuelve 1 si la hora es correcta y acorde a la actual y 0 si ya ha pasado o no es correcta
int comprobarHora_actual(char *, char *);


//Cabecera: int comprobar_hora(char *, char *)
//Precondicion: Recibe dos cadenas de caracteres (hora,minutos)
//Postcondicion: Devuelve 1 si la hora es correcta y 0 si no
int comprobar_hora(char*, char*);


//Cabecera: int comprobacionHoraInicial(char *, char *, char *, char *)
//Precondicion: Recibe cuatro cadenas de caracteres (hora1,minutos1,horas2,minutos2)
//Postcondicion: Devuelve 0 si la segunda hora es menor que la primera y 1 al contrario
int comprobar_hora2_menor_hora1(char *, char *, char *, char *);


//Cabecera: int comprobacionHoraInicial(char *, char *, char *, char *)
//Precondicion: Recibe cuatro cadenas de caracteres (hora1,minutos1,horas2,minutos2)
//Postcondicion: Devuelve 1 si la hora no ha pasado y 0 si ya ha pasado
int comprobacionHoraInicial(char *, char *, char *, char *);


//Cabecera: void comprobaciones_iniciales(viajes *,int)
//Precondicion: Recibe un vector de tipo viajes y un entero (su tama�o)
//Postcondicion: Actualiza en el vector el estado de los viajes segun la hora actual
void comprobaciones_iniciales(viajes *,int);


//Cabecera: int comprobar_id(char *)
//Precondicion: Recibe una cadena de caracteres (un id)
//Postcondicion: Devuelve 1 si el id es uno de los asignados por el sistema a un usuario
int comprobar_id(char *);


//Cabecera: int comprobar_coche(coches *,int,char*)
//Precondicion: Recibe un vector de tipo coches, un entero (su tama�o) y una cadena de caracteres (la matricula)
//Postcondicion: Devuelve 1 si existe el coche y 0 si no
int comprobar_coche(coches *,int,char*);


//Cabecera: void modificar_usuario(usuario *,int,int,int)
//Precondicion: Recibe un vector de tipo usuario y tres enteros (tama�o del vector, la posicion dentro del vector del usuario que la llama y la eleccion procedente del main para el switch)
//Postciondicion: Modifica en el vector la informacion asociada a ese usuario
void modificar_usuario(usuario *,int,int,int);


//Cabecera: void modificar_vehiculo(coches *,int,char *,int)
//Precondicion: Recibe un vector de tipo coches, un entero (su tama�o), una cadena de caracteres (id del usuario que llama a la funcion) y un entero (la eleccion procedente del main para el switch)
//Postciondicion: Modifica en el vector la informacion del vehiculo asociado a la matricula que se introduce dentro de la funcion
void modificar_vehiculo(coches *,int,char *,int);


//Cabecera: void modificar_viajes(coches *,viajes *,int ,int,char *,int)
//Precondicion: Recibe un vector de tipo coches, un vectir de tipo viajes, don enteros (sus tama�os), una cdena de caracteres (id del usuario que llama a la funcion) y un entero (eleccion procedente del main para el switch)
//Postciondicion: Modifica en el vector la informacion asociada a ese usuario
void modificar_viajes(coches *,viajes *,int ,int,char *,int);


//Cabecera: float precio_actualizado(coches *,int,int,float,char *)
//Precondicion: Recibe un vector de tipo coches, dos enteros (su tama�o y el numero de plazas libres), un flotante (el precio del viaje) y una cadena de caracteres (matricula del vehiculo que realiza el viaje)
//Postciondicion: Modifica en el vector el precio acuerdo al numero de plazas y plazas libres
float precio_actualizado(coches *,int,int,float,char *);


//Cabecera: void darse_baja_viaje(viajes *,coches *,int,int)
//Precondicion: Recibe un vector de tipo viajes, un vector de tipo coches y dos enteros (sus tama�os)
//Postcondicion: Permite darse de baja de un viaje (actualizando tanto el precio como el numero de plazas libres)
void darse_baja_viaje(viajes *,coches *,int,int);


//Cabecera: usuario* crearUsuario(usuario*,int*)
//Precondicion: Recibe un vector de tipo usuario y un puntero a entero (su tama�o)
//Postcondicion: Crea un usuario nuevo, devolviendo un vector de tipo usuario y actualizando el tama�o del vector
usuario* crearUsuario(usuario*,int*);


//Cabecera: coches* crearVehiculo(coches *,int *,char *)
//Precondicion: Recibe un vector de tipo coches, un puntero a entero (su tama�o), y una cadena de caracteres (id del usuario que llama a la funcion)
//Postcondicion: Crea un vehiculo nuevo, devolviendo un vector de tipo coches y actualizando el tama�o del vector
coches* crearVehiculo(coches *,int *,char *);


//Cabecera: viajes* crearViajes(viajes *,int *,char *,int,char*)
//Precondicion: Recibe un vector de tipo viajes, un puntero a entero (su tama�o), una cadena de caracteres (matricula del vehiculo que realiza el viaje), un entero (plazas del vehiculo) y una cadena de caracteres
//Postcondicion: Crea un viaje nuevo, devolviendo un vector de tipo viajes, actualizando el tama�o del vector y devolviendo en la ultima cadena el id del viaje
viajes* crearViajes(viajes *,int *,char *,int,char*);


//Cabecera: pasos* crearPasos(pasos *,int *,char *)
//Precondicion: Recibe un vector de tipo pasos, un puntero a entero (su tama�o), y una cadena de caracteres (id del viaje)
//Postcondicion: Crea un paso nuevo, devolviendo un vector de tipo pasos y actualizando el tama�o del vector
pasos* crearPasos(pasos *,int *,char *);


//Cabecera: void unirse_viaje(viajes *,pasos *,coches *,int,int,int,char *)
//Precondicion: Recibe tres vectores (de tipo viajes, pasos y coches), tres enteros (sus tama�os) y una cadena de caracteres (localidad de la que es el usuario)
//Postcondicion: Crea un paso nuevo, devolviendo un vector de tipo pasos, actualizando el tama�o del vector, ademas de, si se desea, listar por pantalla los viajes que cumplen las especificaciones o por contra todos los viajes
void unirse_viaje(viajes *,pasos *,coches *,int,int,int,char *);


//Entero para salvaguardar el importe original del viaje
int aux_importe;

#endif // _ADMINISTRAR_
