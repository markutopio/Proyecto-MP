//Este modulo se encarga de la llamada a todas las funciones y gestion de menus, siendo el responsable de como se ejecuta el proyecto

#ifndef _MAIN_H_
#define _MAIN_H_

#include "cargar.h"
#include "guardar.h"
#include "borrar.h"
#include "administrador.h"

//Cabecera: void inicio_sesion()
//Precondicion: nada
//Postcondicion: muestra por pantalla los menus y funciones a los que llama
void inicio_sesion();


//Cabecera: void opciones_presentacion_usuario()
//Precondicion: nada
//Postcondicion: muestra por pantalla los menus y funciones a los que llama
void opciones_presentacion_usuario();


//Cabecera: void opciones_presentacion_admin()
//Precondicion: nada
//Postcondicion: muestra por pantalla los menus y funciones a los que llama
void opciones_presentacion_admin();


//Enteros que guardarn los tama�os de los vectores
int numUsuarios=0;
int numViajes=0;
int numVehiculos=0;
int numPasos=0;


//Entero que guarda la posicion del usuario dentro del vector de usuarios
int posusu;


//Vectores de los diferentes tipos de datos
usuario *vectUsuarios;
viajes *vectViajes;
coches *vectVehiculos;
pasos *vectPasos;


#endif // _MAIN_H_
