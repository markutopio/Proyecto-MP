#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "borrar.h"

void borrarVehiculo(coches **veh, int *tam, char *id_usu){
    char opcion,aux_mat[8];
    int encontrado=0,i,tamaux=0;
    //Comprobamos que haya al menos un vehiculo, si no que nos de el correspondiente mensaje y no haga nada
    if(*tam>0){
        //Pedimos la matricula del vehiculo
        printf("\nIntroduce la matricula del vehiculo que quieras eliminar: ");
        fflush(stdin);
        gets(aux_mat);
        //Comprobamos si la matricula existe y si esta asociada al usuario que realiza la peticion
        for(i=0;i<(*tam);i++)
            if(strcmp((*veh)[i].id_mat,aux_mat)==0)
                if(strcmp((*veh)[i].id_usuario,id_usu)==0)
                    encontrado=1;
        //Si se ha encontrado y esta asociada a su usuario se procede con el proceso, si no se da el mensaje correspondiente
        if(encontrado==1){
            printf("\nEstas seguro que quieres borrar el vehiculo: (S/N) ");
            fflush(stdin);
            scanf("%c",&opcion);
            if(opcion=='s'||opcion=='S'){
                //Creamos un auxiliar del mismo tipo para poder copiar todos los elementos que no queramos eliminar
                coches *aux;
                //Hacemos reserva de memoria dinamica de un elemento para el auxiliar
                aux=malloc(sizeof(coches));
                for(i=0;i<(*tam);i++){
                    //Si la matricula no coincide con la matricula del vehiculo a eliminar, copiamos la informacion en el auxiliar
                    if(strcmp((*veh)[i].id_mat,aux_mat)!=0){
                        aux[tamaux]=(*veh)[i];
                        tamaux++;
                        aux=realloc(aux,(tamaux+1)*sizeof(coches));
                    }
                }
                //Asignamos el nuevo tama�o del vector al tama�o que recibimos (que es el del vector recibido)
                (*tam)=tamaux;
                free(*veh);
                //Reservamos memoria para el vector que recibimos con el nuevo tama�o
                *veh=malloc((*tam)*sizeof(coches));
                //Copiamos los elementos del auxiliar en el recibido
                (*veh)=aux;
                //Le hacemos un realloc para posibles nuevas interacciones sobre el vector
                *veh=realloc(*veh,((*tam)+1)*sizeof(coches));
                printf("\nVehiculo eliminado\n");
            }
            else
                printf("\nOperacion abortada\n");
        }
        else
            printf("\nEsa matricula o no existe o no esta asociada a su cuenta\n");
    }
    else
        printf("\nNo existen vehiculos registrados\n");
}
