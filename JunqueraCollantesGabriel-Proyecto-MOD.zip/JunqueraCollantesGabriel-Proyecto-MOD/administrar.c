#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "administrar.h"

int login(usuario *usu,int tam,int *pos){
    int i=0,encontrado=0;
    char user[5],password[9];
    //Pedimos un usuario y una contrase�a
    printf("\nEscribe su usuario: ");
    fflush(stdin);
    gets(user);
    printf("\nEscribe su contrase�a: ");
    fflush(stdin);
    gets(password);
    //Recorremos el vector, viendo si ese usuario y esa contrase�a coinciden
    while(i<=tam&&encontrado==0){
        if(strcmp(usu[i].Usuario,user)==0)
            if(strcmp(usu[i].Contrasenna,password)==0)
                if(comprobar_id(usu[i].id_usuario)==1){
                    encontrado=1;
                    //Salvaguardamos la posicion dentro del vector para potenciales usos futuros
                    *pos=i;
                    if(strcmp(usu[(*pos)].Perfil_usuario,"administrador")==0)
                        printf("\n\nBienvenido de nuevo %s (Administrador)",usu[(*pos)].nomb_usuario);
                    else
                        printf("\n\nBienvenido de nuevo %s (Usuario)",usu[(*pos)].nomb_usuario);
                }
        i++;
    }
    //Si no se ha encontrado que de un mensaje por pantalla
    if(encontrado==0)
        puts("\n\nUsuario o contrase�a no validos, vuelva a intentarlo o cree un nuevo usuario\n\n");
    return encontrado;
}

void asignar_id_usuario(usuario *usuario,int tama,char *id_usu){
    int j,i,salir=0,encontrado;
    //Iniciamos el vector como 0001
    char vector[5] = "0001";
    //Se hara el bucle mientras no sea 9999 el vector y mientras salir sea 0
    while ((strcmp(vector, "9999"))!=0&&salir==0) {
        encontrado=0;
        i=0;
        //Comprobamos que ese id no existe ya, si existe encontrado sera 1, si no existe sera 0
        while(i<tama&&encontrado==0){
            if (strcmp(vector,usuario[i].id_usuario) == 0)
                    encontrado=1;
            i++;
        }
        //Cuando encontrado sea 0, copiamos el id libre a la cadena recibida por la funcion
        if(encontrado==0){
            strcpy(id_usu,vector);
            //Utilizamos la variable salir para que si lo ha encontrado salga del bucle while
            salir=1;
        }
        //Aumento del vector
        j=3;
        while (vector[j] == '9') {
            vector[j] = '0';
            j--;
        }
        vector[j]++;
    }
}

void asignar_id_viaje(viajes *viaj,int tam,char *id_viaj){
    int j,i,salir=0,encontrado;
    //Iniciamos el vector en 000001
    char vector[7] = "000001";
    //Haremos el while mientras el vector no sea 999999 y salir sea 0
    while ((strcmp(vector, "999999"))!=0&&salir==0) {
        encontrado=0;
        i=0;
        //Comprobamos si ese id no existe ya, si existe encontrado sera 1, si no sera 0
        while(i<tam&&encontrado==0){
            if (strcmp(vector,viaj[i].id_viaje) == 0)
                    encontrado=1;
            i++;
        }
        //Si no existe un id igual, entonces copiamos ese id en la cadena recibida por la funcion
        if(encontrado==0){
            strcpy(id_viaj,vector);
            //Ponemos salir a 1 para salir del bucle while
            salir=1;
        }
        //Aumento del vector
        j=5;
        while (vector[j] == '9') {
            vector[j] = '0';
            j--;
        }
        vector[j]++;
    }
}

void listar_usuarios(usuario *usu,int tam,int pos){
    //Imprimimos los datos de la persona asociada la posicion que recibe la funcion
    printf("-----------------------------------------------------------------------\n");
    printf("La lista de datos asociados a su cuenta es: \n\n");
    printf("%s-%s-%s-%s-%s-%s",usu[pos].id_usuario,usu[pos].nomb_usuario,usu[pos].Localidad,usu[pos].Perfil_usuario,usu[pos].Usuario,usu[pos].Contrasenna);
    printf("\n\n");
    printf("\n------------------------------------------------------------------------");
}

void listar_vehiculos(coches *coch, int tam_veh,char *id_usu){
    int i,posicion,encontrado=0;
    //Comprobamos que hay al menus un vehiculo, si no dara un mensaje directo por pantalla
    if (tam_veh > 0) {
        printf("-----------------------------------------------------------------------\n");
        printf("La lista de vehiculos asociados a su cuenta es: \n\n");
        //Recorremos todo el vector, y si coincide el id de usuario con el que recibe la funcion, imprimimos los vehiculos
        for(i=0;i<tam_veh;i++)
            if(strcmp(coch[i].id_usuario,id_usu)==0){
                posicion=i;
                printf("%s-%s-%i-%s", coch[posicion].id_mat, coch[posicion].id_usuario, coch[posicion].Num_plazas, coch[posicion].Desc_veh);
                printf("\n\n");
                encontrado=1;
            }
        printf("\n------------------------------------------------------------------------");
        //Si no se han encontrado vehiculos asociados a esa cuenta, entonces dara un mensaje
        if(encontrado!=1){
            printf("\nNo hay vehiculos asociados\n");
        }
    }
    else
        printf("\nNo hay vehiculos disponibles.\n");
}

void listar_viajes(viajes *viaj,int tam_viaj){
    int i;
    //Comprobamos que haya al menos un viaje, si no dara el correspondiente mensaje
    if(tam_viaj>0){
        printf("-----------------------------------------------------------------------\n");
        printf("La lista de viajes registrados es: \n\n");
        //Recorremos el vector imprimiendo todos los datos que tenga
        for(i=0;i<tam_viaj;i++){
            printf("%s-%s-%.2i/%.2i/%i-%.2i:%.2i-%.2i:%.2i-%i-%s-%.2f-%s",viaj[i].id_viaje,viaj[i].id_mat,viaj[i].F_inic.dia,viaj[i].F_inic.mes,viaj[i].F_inic.anio,viaj[i].H_inic.hora,viaj[i].H_inic.minu,viaj[i].H_fin.hora,viaj[i].H_fin.minu,viaj[i].plazas_libres,viaj[i].id_vuelta,viaj[i].importe,viaj[i].estado);
            printf("\n\n");
        }
        printf("\n------------------------------------------------------------------------");
    }
    else
        printf("\nNo hay viajes disponibles en este momento\n");
}

void listar_viajes_detallado(viajes *viaj,pasos *pas,int tam_viaj,int tam_pas){
    int i,encontrado=0;
    char aux_id[7];
    //Introducimos el id del viaje del que se quiere saber mas informacion
    if(tam_viaj>0){
        printf("\nIntroduce el id del viaje a visualizar: ");
        fflush(stdin);
        gets(aux_id);
        printf("-----------------------------------------------------------------------\n");
        printf("Informacion asociada a ese viaje: \n\n");
        //Recorremos el vector, y si coincide algun id de viajes con el dado, imprime su informacion
        for(i=0;i<tam_viaj;i++){
            if(strcmp(viaj[i].id_viaje,aux_id)==0){
                printf("%s-%s-%.2i/%.2i/%i-%.2i:%.2i-%.2i:%.2i-%i-%s-%.2f-%s",viaj[i].id_viaje,viaj[i].id_mat,viaj[i].F_inic.dia,viaj[i].F_inic.mes,viaj[i].F_inic.anio,viaj[i].H_inic.hora,viaj[i].H_inic.minu,viaj[i].H_fin.hora,viaj[i].H_fin.minu,viaj[i].plazas_libres,viaj[i].id_vuelta,viaj[i].importe,viaj[i].estado);
                printf("\n\n");
                encontrado=1;
            }
        }
        //Si lo ha encontrado, imprime las poblaciones por las que pasa, si no dara un mensaje
        if(encontrado==1){
            printf("Poblaciones por las que pasa: ");
            for(i=0;i<tam_pas;i++)
                if(strcmp(pas[i].id_viaje,aux_id)==0)
                    printf("%s, ",pas[i].poblacion);
        }
        else
            printf("\nNo se ha encontrado un viaje con ese id\n");
        printf("\n------------------------------------------------------------------------");
    }
    else
        printf("\nNo hay viajes disponibles en este momento\n");
}

void listar_viajes_vehiculo(viajes *viaj,int tam_viaj){
    int i,encontrado=0;
    char mat[8];
    if(tam_viaj>0){
        //Pedimos la matricula del vehiculo que se quiera saber todos sus viajes
        printf("\nIntroduce la matricula del vehiculo del que quieras saber todos los viajes realizados: ");
        fflush(stdin);
        gets(mat);
        printf("-----------------------------------------------------------------------\n");
        printf("Viajes asociados a ese vehiculo: \n\n");
        //Recorremos el vector, e imprimimos todo lo que haya asociado a esa matricula
        for(i=0;i<tam_viaj;i++)
            if(strcmp(viaj[i].id_mat,mat)==0){
                printf("%s-%s-%.2i/%.2i/%i-%.2i:%.2i-%.2i:%.2i-%i-%s-%.2f-%s",viaj[i].id_viaje,viaj[i].id_mat,viaj[i].F_inic.dia,viaj[i].F_inic.mes,viaj[i].F_inic.anio,viaj[i].H_inic.hora,viaj[i].H_inic.minu,viaj[i].H_fin.hora,viaj[i].H_fin.minu,viaj[i].plazas_libres,viaj[i].id_vuelta,viaj[i].importe,viaj[i].estado);
                printf("\n\n");
                encontrado=1;
            }
        printf("\n------------------------------------------------------------------------");
        //Si no ha encontrado nada, dara el mensaje correspondiente
        if(encontrado==0)
            printf("\nNo hay viajes asociados a esa matricula\n");
    }
    else
        printf("\nNo hay viajes registrados\n");
}

int comprobar_nickname(usuario *usu,int numusuarios,char *nombusu){
    int i=0,retorno=0;
    //Mientras no se acabe el vector y salir sea 0, realizamos la comprobacion
    while(i<numusuarios){
        //Si se encuentra algun nickname en el vector igual al recibido, devolvera 1 y salir sera 1 de manera que saldra del while
        if(strcmp(usu[i].Usuario,nombusu)==0)
            retorno=1;
        i++;
    }
    return retorno;
}

int comprobar_admin (usuario *usu,int pos){
    int admin=0;
    //Si la letra asociada a perfil de usuario en el vector usuario del usuario cuya posicion se recibe es a o A, la funcion devuelve 1
    if(strcmp(usu[pos].Perfil_usuario,"administrador")==0)
        admin=1;
    return admin;
}

int comprobar_vehiculos_asociado(coches *coch,int tam,char *id){
    int i,encontrado=0;
    //Recorremos todo el vector, y si coincide el id del usuario (que recibe la funcion) y el id del vector, devuleve 1
    for(i=0;i<tam;i++)
        if(strcmp(coch[i].id_usuario,id)==0)
            encontrado=1;
    //Si no se ha encontrado, da un mensaje
    if(encontrado!=1)
        printf("\nNo hay vehiculos asociados a tu usuario\n");
    return encontrado;
}

int comprobar_matricula_id(coches *coch,int tam,char *id,char *auxmatri,int *auxplazas){
    int i,encontrado=0;
    char mat[8];
    //Pedimos la matricula del vehiculo
    printf("\nIntroduzca la matricula del vehiculo que realizara el viaje: ");
    fflush(stdin);
    gets(mat);
    //Si recorremos el vector y esa matricula no existe, o no esta asociada con el id que recibe la funcion, encontrado sera 0
    for(i=0;i<tam;i++)
        if(strcmp(coch[i].id_mat,mat)==0)
            if(strcmp(coch[i].id_usuario,id)==0){
                encontrado=1;
                //Pasamos a los parametros auxplazas y auxmatri el numero de plazas del coche y la matricula
                strcpy(auxmatri,mat);
                *auxplazas=coch[i].Num_plazas;
            }
    //Si no se ha encontrado, dara un mensaje
    if(encontrado!=1)
        printf("\nLa matricula introducida no existe o no esta asociada a tu usuario\n");
    return encontrado;
}

int comprobarFecha(char *dia_cad, char *mes_cad, char *anio_cad){
  //Obtenemos la fecha y hora actual del sistema
  time_t current_time=time(NULL);
  struct tm*current_tm=localtime(&current_time);

  //Convertimos las cadenas de caracteres a enteros
  int dia=atoi(dia_cad);
  int mes=atoi(mes_cad);
  int anio=atoi(anio_cad);

  //Verificamos si la fecha es v�lida
  if (dia<1||dia>31||mes<1||mes>12||anio<1900)
    return 0; // Fecha incorrecta

  //Verificamos si febrero tiene 28 o 29 d�as dependiendo del a�o bisiesto
  int feb_max_days=28;
  if ((anio%4==0&&anio%100!=0)||anio%400==0)
    feb_max_days = 29;

  //Verificamos si el d�a es v�lido para el mes especificado
  int max_days=31;
  if (mes==2)
    max_days=feb_max_days;
  else
    if (mes==4||mes==6||mes==9||mes==11)
        max_days=30;
  if (dia<1||dia>max_days)
    return 0; // Fecha incorrecta

  //Creamos una estructura tm con la fecha especificada
  struct tm input_tm=*current_tm;
  input_tm.tm_mday=dia;
  input_tm.tm_mon=mes-1;
  input_tm.tm_year=anio-1900;

  //Convertimos ambas estructuras tm a time_t
  time_t input_time=mktime(&input_tm);
  time_t current_time_plus_one_minute=current_time+60;

  //Comparamos la fecha especificada con la actual
  if (input_time<current_time){
    return 0; // Fecha anterior a la actual
  }
  else
    if (input_time >= current_time && input_time < current_time_plus_one_minute)
        return 1; //Fecha actual del sistema
    else
        return 2; //Fecha futura
}

int comprobarHora_actual(char *horas, char *minutos) {
    time_t now=time(NULL);
    struct tm *tm=localtime(&now);
    int hora_actual=tm->tm_hour;
    int minuto_actual=tm->tm_min;
    // Convertimos cadena de caracteres a entero
    int hora=atoi(horas);
    int minuto=atoi(minutos);
    if(hora>23||hora<0||minuto>59||minuto<0)
        return 0; //La hora es incorrecta
    else
        if(hora<hora_actual||(hora==hora_actual&&minuto<=minuto_actual))
            return 0; //La hora ya ha pasado
        else
            return 1; //La hora es acorde a la actual
}

int comprobar_hora(char *horas, char *minutos) {
    // Convertimos de cadena de caracteres a entero en base 10
    int horas_int=strtol(horas,NULL,10);
    int minutos_int=strtol(minutos,NULL,10);
    if(horas_int<0||horas_int>23||minutos_int<0||minutos_int>59)
        return 0; //La hora es incorrecta
    else
        return 1; //La hora es correcta
}

int comprobar_hora2_menor_hora1(char *hora1_cad, char *minutos1_cad, char *hora2_cad, char *minutos2_cad){
  //Convertimos las cadenas de caracteres a enteros
  int hora1=atoi(hora1_cad);
  int minutos1=atoi(minutos1_cad);
  int hora2=atoi(hora2_cad);
  int minutos2=atoi(minutos2_cad);

  //Comparamos las horas y minutos
  if (hora2<hora1) {
    return 0; // La segunda hora es anterior a la primera
  } else if (hora2==hora1&&minutos2<minutos1) {
    return 0; // La segunda hora es anterior a la primera
  } else {
    return 1; // La segunda hora no es anterior a la primera
  }
}

int comprobacionHoraInicial(char *horas1, char *minutos1, char *horas2, char *minutos2) {
    time_t ahora=time(NULL);
    struct tm *local=localtime(&ahora);
    int hora_actual=local->tm_hour;
    int min_actual=local->tm_min;
    // Convertimos cadena de caracteres a entero
    int hora1=atoi(horas1);
    int min1=atoi(minutos1);
    int hora2=atoi(horas2);
    int min2=atoi(minutos2);
    if(hora1<hora_actual||(hora1==hora_actual&&min1<=min_actual))
        if(hora2>hora_actual||(hora2==hora_actual&&min2>min_actual))
            return 1; //La hora 1 ya ha pasado pero la hora 2 aun no
    return 0; //La hora 1 aun no ha pasado o la hora 2 ya ha pasado
}

void comprobaciones_iniciales(viajes *viaj,int tam){
    int i,hora_int,min_int;
    time_t ahora=time(NULL);
    struct tm *local=localtime(&ahora);
    int hora_actual=local->tm_hour;
    int min_actual=local->tm_min;
    char dia[3],mes[3],anio[5],hora[3],min[3],hora2[3],min2[3];
    //Recorremos todo el vector para realizar las comprobaciones de cada caso
    for(i=0;i<tam;i++){
        //Si ya no quedan plazas libres, pondemos el estado en cerrado
        if(viaj[i].plazas_libres==0)
            strcpy(viaj[i].estado,"cerrado");
        //Si la hora inicial y final ya ha pasado, hace justo una hora o mas, ponemos el estado como finalizado
        //Pasamos los datos almacenados en las estructuras a cadenas para poder pasarlo a las funciones
        hora_int=viaj[i].H_fin.hora;
        min_int=viaj[i].H_fin.minu;
        sprintf(dia,"%i",viaj[i].F_inic.dia);
        sprintf(mes,"%i",viaj[i].F_inic.mes);
        sprintf(anio,"%i",viaj[i].F_inic.anio);
        if(comprobarFecha(dia,mes,anio)==1){
            if((hora_int+1==hora_actual&&min_int==min_actual)||hora_int+1<hora_actual)
                strcpy(viaj[i].estado,"finalizado");
            //Pasamos los datos almacenados en las estructuras a cadenas para poder pasarlo a las funciones
            sprintf(hora,"%i",viaj[i].H_inic.hora);
            sprintf(min,"%i",viaj[i].H_inic.minu);
            sprintf(hora2,"%i",viaj[i].H_fin.hora);
            sprintf(min2,"%i",viaj[i].H_fin.minu);
            //Si la hora inicial ya ha pasado pero la final no, ponemos el estado como iniciado
            if(comprobacionHoraInicial(hora,min,hora2,min2)==1)
                strcpy(viaj[i].estado,"iniciado");
        }
    }
}

int comprobar_id(char *id_usu){
    int j,salir=0,encontrado;
    //Iniciamos el vector como 0001
    char vector[5] = "0001";
    //Se hara el bucle mientras no sea 9999 el vector y mientras salir sea 0
    while ((strcmp(vector, "9999"))!=0&&salir==0) {
        encontrado=0;
        //Comprobamos que ese id no existe ya, si existe encontrado sera 1, si no existe sera 0
        while(encontrado==0){
            if (strcmp(vector,id_usu) == 0){
                encontrado=1;
                salir=1;
            }
            j=3;
            while (vector[j] == '9') {
                vector[j] = '0';
                j--;
            }
            vector[j]++;
        }
        //Aumento del vector
    }
    return encontrado;
}

int comprobar_coche (coches *coch,int tam,char *mat){
    int i=0,encontrado=0;
    //Recorremos el vector de vehiculos, y si coincide alguna matricula con la recibida, devuelve 1
    while(i<=tam&&encontrado==0){
        if(strcmp(coch[i].id_mat,mat)==0)
            encontrado=1;
        i++;
    }
    return encontrado;
}

void modificar_usuario(usuario *usu,int tam,int pos,int eleccion){
    char aux_nickname[6];
    int opcion;
    //Hacemos un switch del entero que recibimos desde el main
    switch(eleccion){
        case 1:
            //Modificacion del nombre de usuario
            printf("\nIntroduce el nuevo nombre de usuario: ");
            fflush(stdin);
            gets(usu[pos].nomb_usuario);
            break;
        case 2:
            //Modificacion de la localidad
            do{
                localidad();
                fflush(stdin);
                scanf("%i",&opcion);
                if(opcion>10||opcion<1)
                    printf("\nIntroduce una opcion valida\n");
            }while(opcion>10||opcion<1);
            switch(opcion){
                case 1:
                    strcpy(usu[pos].Localidad,"Cadiz");
                    break;
                case 2:
                    strcpy(usu[pos].Localidad,"Puerto Real");
                    break;
                case 3:
                    strcpy(usu[pos].Localidad,"San Fernando");
                    break;
                case 4:
                    strcpy(usu[pos].Localidad,"Chiclana");
                    break;
                case 5:
                    strcpy(usu[pos].Localidad,"Jerez");
                    break;
                case 6:
                    strcpy(usu[pos].Localidad,"Puerto Santa Maria");
                    break;
                case 7:
                    strcpy(usu[pos].Localidad,"Barbate");
                    break;
                case 8:
                    strcpy(usu[pos].Localidad,"Conil");
                    break;
                case 9:
                    strcpy(usu[pos].Localidad,"Rota");
                    break;
                case 10:
                    strcpy(usu[pos].Localidad,"Algeciras");
                    break;
            }
            break;
        case 3:
            //Modificacion del nickname
            do{
                printf("\nIntroduce el nuevo nickname: ");
                fflush(stdin);
                gets(aux_nickname);
                //Comprobamos si el nickname ya existe
                if(comprobar_nickname(usu,tam,aux_nickname)==1)
                    printf("\nEse usuario ya existe. Prueba con otro\n");
            }while(comprobar_nickname(usu,tam,aux_nickname)==1);
            strcpy(usu[pos].Usuario,aux_nickname);
            break;
        case 4:
            //Modificacion de la contrase�a
            printf("\nIntroduce la nueva contrasenna: ");
            fflush(stdin);
            gets(usu[pos].Contrasenna);
            break;
    }
    printf("\nUsuario modificado con exito\n\n");
}

void modificar_vehiculo(coches *coch,int tam,char *id_usu,int eleccion){
    char aux_mat[8],mat[8];
    int posicion,i,encontrado=0,plazas;
    //Comprobamos si hay al menos un vehiculo, si no, entonces da un mensaje por pantalla
    if(tam>0){
        //Pedimos la matricula del vehiculo a modificar
        printf("\nIntroduce la matricula del vehiculo a modificar: ");
        fflush(stdin);
        gets(mat);
        //Comprobamos que esa matricula exista y que este asociada al usuario cuyo id recibe la funcion
        for(i=0;i<tam;i++)
            if(strcmp(coch[i].id_mat,mat)==0){
                if(strcmp(coch[i].id_usuario,id_usu)==0){
                    encontrado=1;
                    //Salvaguardamos la posicion para poder modificarlo mas directamente
                    posicion=i;
                }
            }
        //Si se ha encontrado esa matricula y coincide con el id recibido, se sigue con la modificacion
        if(encontrado==1){
            //Hacemos un switch del entero recibido del main
            switch(eleccion){
                case 1:
                    //Modificacion de la matricula
                    do{
                        printf("\nIntroduce la nueva matricula: ");
                        fflush(stdin);
                        gets(aux_mat);
                        //Comprobamos si la matricula introducida ya existe
                        if(comprobar_coche(coch,tam,aux_mat)==1)
                            printf("\nMatricula ya existente\n");
                    }while(comprobar_coche(coch,tam,aux_mat)==1);
                    strcpy(coch[posicion].id_mat,aux_mat);
                    break;
                case 2:
                    //Modificacion del numero de plazas
                    do{
                        printf("\nIntroduce el nuevo numero de plazas (sin contar la del conductor): ");
                        fflush(stdin);
                        scanf("%i",&plazas);
                    }while(plazas<1||plazas>=10);
                    coch[posicion].Num_plazas=plazas;
                    break;
                case 3:
                    //Modificacion de la descripcion
                    printf("\nIntroduce la nueva descripcion (50 caracteres maximo)");
                    fflush(stdin);
                    gets(coch[posicion].Desc_veh);
                    break;
            }
            printf("\nVehiculo modificado con exito\n");
        }
        else
            printf("\nEsa matricula no esta asociada a su cuenta o no existe\n");
    }
    else
        printf("\nNo hay vehiculos registrados\n");
}

void modificar_viajes(coches *coch,viajes *viaj,int tam_viaj,int tam_coch,char *id_usu,int eleccion){
    char aux_id[7],opcion[7],dia[3],mes[3],anio[5],hora[3],minuto[3],aux_hora[3],aux_min[3];
    int i,j,correcto=0,encontrado=0;
    //Comprobamos que haya al menos un viaje, si no dara un mensaje directamente
    if(tam_viaj>0){
        //Pedimos el id del viaje a modificar
        printf("\nIntroduce el id del viaje: ");
        fflush(stdin);
        gets(aux_id);
        //Comprobamos que ese id este asociado a un viaje, y que el numero de plazas libres coincida con el original
        for(j=0;j<tam_viaj;j++)
            if(strcmp(viaj[j].id_viaje,aux_id)==0)
                for(i=0;i<tam_coch;i++)
                    if(strcmp(coch[i].id_mat,viaj[j].id_mat)==0)
                        if(strcmp(coch[i].id_usuario,id_usu)==0)
                            if(viaj[j].plazas_libres==coch[i].Num_plazas){
                                encontrado=1;
                                //Hcemos un switch de la eleccion procedente del main
                                switch(eleccion){
                                    case 1:
                                        //Modificacion de la fecha
                                        do{
                                            correcto=0;
                                            printf("\nIntroduzca el d�a del viaje en formato DD: ");
                                            fflush(stdin);
                                            scanf("%s",dia);
                                            printf("\nIntroduzca el mes en formato MM: ");
                                            fflush(stdin);
                                            scanf("%s",mes);
                                            printf("\nIntroduzca el a�o en formato AAAA: ");
                                            fflush(stdin);
                                            scanf("%s",anio);
                                            //Comprobamos si la fecha introducida es correcta, haciendo diferenciacion entre si es laactual o no
                                            //Si la fecha es la actual, tendremos que comprobar que las horas almacenadas se ajustan a la actual
                                            if(comprobarFecha(dia,mes,anio)==1){
                                                //Pasamos de entero a cadena para poder pasar los parametros a la funcion de a continuacion
                                                sprintf(hora,"%i",viaj[j].H_inic.hora);
                                                sprintf(minuto,"%i",viaj[j].H_inic.minu);
                                                //Comprobamos que la hora de inicio no haya pasado, en ese caso, almacenamos la fecha
                                                if(comprobarHora_actual(hora,minuto)==1){
                                                    //Pasamos de cadena a entero para poder pasarselo a la funcion
                                                    viaj[j].F_inic.dia=atoi(dia);
                                                    viaj[j].F_inic.mes=atoi(mes);
                                                    viaj[j].F_inic.anio=atoi(anio);
                                                    correcto=1;
                                                }
                                                //Si ha pasado, comprobamos si la final aun no ha pasado, en ese caso almacenamos tambien la fecha
                                                else{
                                                    //Pasamos de entero a cadena para poder pasarselo a la funcion
                                                    sprintf(hora,"%i",viaj[j].H_fin.hora);
                                                    sprintf(minuto,"%i",viaj[j].H_fin.minu);
                                                    if(comprobarHora_actual(hora,minuto)==1){
                                                        //Pasamos de cadena a entero para poder almacenarlo en el vector
                                                        viaj[j].F_inic.dia=atoi(dia);
                                                        viaj[j].F_inic.mes=atoi(mes);
                                                        viaj[j].F_inic.anio=atoi(anio);
                                                        correcto=1;
                                                    }
                                                }
                                            }
                                            //Si la fecha no es la de hoy, independientemente de la hora, almacenamos la nueva
                                            if(comprobarFecha(dia,mes,anio)==2){
                                                viaj[j].F_inic.dia=atoi(dia);
                                                viaj[j].F_inic.mes=atoi(mes);
                                                viaj[j].F_inic.anio=atoi(anio);
                                                correcto=1;
                                            }
                                            //Si la fecha no es correcta o ya ha pasado, o es la actual pero las horas que habia metidas ya han pasado, que de un mensaje y repita el bucle
                                            if(correcto==0)
                                                printf("\nIntroduce una fecha valida y acorde a la actual (si la fecha es la actual la hora tambien debe estar correcta)\n");
                                        }while(correcto==0);
                                        break;
                                    case 2:
                                        //Modificacion de la hora de inicio
                                        //Pasamos de entero (lo que haya en la estructura) a cadena para la funcion
                                        sprintf(dia,"%i",viaj[j].F_inic.dia);
                                        sprintf(mes,"%i",viaj[j].F_inic.mes);
                                        sprintf(anio,"%i",viaj[j].F_inic.anio);
                                        //Si la fecha es la actual, entonces comprueba la hora con la actual
                                        if(comprobarFecha(dia,mes,anio)==1){
                                            do{
                                                correcto=0;
                                                printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
                                                fflush(stdin);
                                                scanf("%s",hora);
                                                printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
                                                fflush(stdin);
                                                scanf("%s",minuto);
                                                //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                                sprintf(aux_hora,"%i",viaj[j].H_fin.hora);
                                                sprintf(aux_min,"%i",viaj[j].H_fin.minu);
                                                //Comprobamos que la hora de llegada es posterior a la de inicio introducida
                                                if(comprobar_hora2_menor_hora1(hora,minuto,aux_hora,aux_min)==1){
                                                    //Comprobamos si la hora es correcta con respecto a la actual
                                                    correcto=comprobarHora_actual(hora,minuto);
                                                    if(correcto==0)
                                                        printf("\nIntroduce una hora valida y acorde a la actual\n");
                                                }
                                                else
                                                    printf("\nLa hora de inicio no tiene sentido respecto de la de finalizacion\n");
                                            }while(correcto!=1);
                                            //Pasamos de cadena a entero para almacenar en vector
                                            viaj[j].H_inic.minu=atoi(minuto);
                                            viaj[j].H_inic.hora=atoi(hora);
                                        }
                                        //Si no es la actual, debe comprobar la hora sin tener en cuenta la actual
                                        else{
                                            do{
                                                correcto=0;
                                                printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
                                                fflush(stdin);
                                                scanf("%s",hora);
                                                printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
                                                fflush(stdin);
                                                scanf("%s",minuto);
                                                //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                                sprintf(aux_hora,"%i",viaj[j].H_fin.hora);
                                                sprintf(aux_min,"%i",viaj[j].H_fin.minu);
                                                //Comprobamos que la hora de llegada es posterior a la de inicio introducida
                                                if(comprobar_hora2_menor_hora1(hora,minuto,aux_hora,aux_min)==1){
                                                    //Comprobamos si la hora es correcta con respecto a la actual
                                                    correcto=comprobar_hora(hora,minuto);
                                                    if(correcto==0)
                                                        printf("\nIntroduce una hora valida y acorde a la actual\n");
                                                }
                                                else
                                                    printf("\nLa hora de inicio no tiene sentido respecto de la de finalizacion\n");
                                            }while(correcto!=1);
                                            //Pasamos de cadena a entero para almacenar en vector
                                            viaj[j].H_inic.minu=atoi(minuto);
                                            viaj[j].H_inic.hora=atoi(hora);
                                        }
                                        break;
                                    case 3:
                                        //Modificacion de la hora de llegada
                                        //Pasamos de entero (lo que haya en la estructura) a cadena para la funcion
                                        sprintf(dia,"%i",viaj[j].F_inic.dia);
                                        sprintf(mes,"%i",viaj[j].F_inic.mes);
                                        sprintf(anio,"%i",viaj[j].F_inic.anio);
                                        //Si la fecha es la actual, entonces comprueba la hora con la actual
                                        if(comprobarFecha(dia,mes,anio)==1){
                                             do{
                                                correcto=0;
                                                printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
                                                fflush(stdin);
                                                scanf("%s",hora);
                                                printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
                                                fflush(stdin);
                                                scanf("%s",minuto);
                                                //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                                sprintf(aux_hora,"%i",viaj[j].H_inic.hora);
                                                sprintf(aux_min,"%i",viaj[j].H_inic.minu);
                                                //Comprobamos que la hora de llegada introducida es posterior a la de inicio
                                                if(comprobar_hora2_menor_hora1(aux_hora,aux_min,hora,minuto)==1){
                                                    //Comprobamos si la hora es correcta con respecto a la actual
                                                    correcto=comprobarHora_actual(hora,minuto);
                                                    if(correcto==0)
                                                        printf("\nIntroduce una hora valida y acorde a la actual\n");
                                                }
                                                else
                                                    printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
                                            }while(correcto!=1);
                                            //Pasamos de cadena a entero para almacenar en vector
                                            viaj[j].H_fin.minu=atoi(minuto);
                                            viaj[j].H_fin.hora=atoi(hora);
                                        }
                                        //Si no es la actual, debe comprobar la hora sin tener en cuenta la actual
                                        else{
                                            do{
                                                correcto=0;
                                                printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
                                                fflush(stdin);
                                                scanf("%s",hora);
                                                printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
                                                fflush(stdin);
                                                scanf("%s",minuto);
                                                //Pasamos a cadena la hora de llegada para pasarlo a la funcion posterior
                                                sprintf(aux_hora,"%i",viaj[j].H_inic.hora);
                                                sprintf(aux_min,"%i",viaj[j].H_inic.minu);
                                                //Comprobamos que la hora de llegada introducida es posterior a la de inicio
                                                if(comprobar_hora2_menor_hora1(aux_hora,aux_min,hora,minuto)==1){
                                                    //Comprobamos si la hora es correcta con respecto a la actual
                                                    correcto=comprobar_hora(hora,minuto);
                                                    if(correcto==0)
                                                        printf("\nIntroduce una hora valida y acorde a la actual\n");
                                                }
                                                else
                                                    printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
                                            }while(correcto!=1);
                                            //Pasamos de cadena a entero para almacenar en vector
                                            viaj[j].H_fin.minu=atoi(minuto);
                                            viaj[j].H_fin.hora=atoi(hora);
                                        }
                                        break;
                                    case 4:
                                        //Modificacion del importe
                                        printf("\nIntroduce el nuevo importe: ");
                                        scanf("%f",&viaj[j].importe);
                                        break;
                                    case 5:
                                        //Modificacion de si el viaje es de ida o vuelta
                                        do{
                                            correcto=0;
                                            printf("\nIntroduce si el viaje es de ida o de vuelta (poner ida o vuelta): ");
                                            fflush(stdin);
                                            gets(opcion);
                                            //Si no se ha introducido la plabra ida o vuelta, entonces saldra el mensaje y se repetira la funcion
                                            if(strcmp(opcion,"ida")!=0&&strcmp(opcion,"vuelta")!=0){
                                                printf("\nPalabra introducida incorrecta. Escribela tal y como aparece en la reclamacion del dato\n");
                                                correcto=1;
                                            }
                                        }while(correcto==1);
                                        strcpy(viaj[j].id_vuelta,opcion);
                                        break;
                                    case 6:
                                        //Como el hecho de que llegue aqui significa que no se ha apuntado nadie al viaje, entonces podemos poner anulado directamente
                                        strcpy(viaj[j].estado,"anulado");
                                        break;
                            }
                            printf("\nViaje modificado con exito\n");
                        }
        //Si no se ha encontrado, que de un mensaje por pantalla
        if(encontrado==0)
            printf("\nNo se puede modificar, ya sea porque no existe un viaje con ese id, por no ser el creador del viaje, o porque hay gente apuntada\n");
    }
    else
        printf("\nNo existen viajes disponibles para modificar\n");
}

float precio_actualizado(coches *coche,int tam,int plazaslibres,float precio,char *mat){
    int i;
    float precio_nuevo;
    //Recorre el vector de vehiculos y, segun la diferencia de las plazas libres o no, actualiza el precio
    for(i=0;i<tam;i++)
        if(strcmp(coche[i].id_mat,mat)==0){
            if(coche[i].Num_plazas!=plazaslibres){
                plazaslibres--;
                precio_nuevo=(precio/(coche[i].Num_plazas-plazaslibres));
            }
            else
                precio_nuevo=precio;
        }
    return precio_nuevo;
}

void darse_baja_viaje(viajes *viaj,coches *coch,int tam_viaj,int tam_coch){
    char aux_id[7];
    int i,j,encontrado=0;
    //Pedimos el id del viaje al que el usuario se apunto
    printf("\nIntroduce el id del viaje al que te apuntaste: ");
    fflush(stdin);
    gets(aux_id);
    //Recorremos el vector y si existe un viaje con ese id
    for(i=0;i<tam_viaj;i++)
        if(strcmp(viaj[i].id_viaje,aux_id)==0)
            for(j=0;j<tam_coch;j++)
                if(strcmp(viaj[i].id_mat,coch[j].id_mat)==0)
                    //Se comprueba que efectivamente haya menos plazas libres que las originales
                    if(viaj[i].plazas_libres!=coch[j].Num_plazas)
                        //Comprobamos que todavia se pueda dar de baja (estado en abierto)
                        if(strcmp(viaj[i].estado,"abierto")==0){
                            //Actualizamos el importe y el numero de plazas libres
                            viaj[i].plazas_libres+=1;
                            viaj[i].importe=precio_actualizado(coch,tam_coch,viaj[i].plazas_libres,aux_importe,viaj[i].id_mat);
                            encontrado=1;
                        }
    //Si no se ha encontrado que de un mensaje por pantalla
    if(encontrado==0)
        printf("\nNo puede darse de baja ya sea porque no existe viaje con ese id, porque ya esta iniciado o porque no se apunto en el\n");
    else
        printf("\nOperacion realizada con exito\n");
}

usuario* crearUsuario(usuario *usu,int *tam){
    int nickname,opcion;
    char aux_nickname[6],aux_admin,admin[12],vect_aux_id[5];
    //Si el tama�o del vector es 0, directamente asignamos el id 0000
    if((*tam)==0)
        strcpy(vect_aux_id,"0001");
    //Si no, llamamos a la funcion que asigna el id
    else
        asignar_id_usuario(usu,(*tam),vect_aux_id);
    strcpy(usu[(*tam)].id_usuario,vect_aux_id);
    //Pedimos el nombre
    printf("\nIntroduzca el nombre completo (20 caracteres max): ");
    fflush(stdin);
    gets(usu[(*tam)].nomb_usuario);
    do{
        //Pedimos la localidad
        localidad();
        fflush(stdin);
        scanf("%i",&opcion);
        //Si la opcion no es valida da el mensaje y repite el bucle
        if(opcion>10||opcion<1)
            printf("\nIntroduce una opcion valida\n");
    }while(opcion>10||opcion<1);
    switch(opcion){
        case 1:
            strcpy(usu[*tam].Localidad,"Cadiz");
            break;
        case 2:
            strcpy(usu[*tam].Localidad,"Puerto Real");
            break;
        case 3:
            strcpy(usu[*tam].Localidad,"San Fernando");
            break;
        case 4:
            strcpy(usu[*tam].Localidad,"Chiclana");
            break;
        case 5:
            strcpy(usu[*tam].Localidad,"Jerez");
            break;
        case 6:
            strcpy(usu[*tam].Localidad,"Puerto Santa Maria");
            break;
        case 7:
            strcpy(usu[*tam].Localidad,"Barbate");
            break;
        case 8:
            strcpy(usu[*tam].Localidad,"Conil");
            break;
        case 9:
            strcpy(usu[*tam].Localidad,"Rota");
            break;
        case 10:
            strcpy(usu[*tam].Localidad,"Algeciras");
            break;
    }
    //Le pedimos que introduzca si es usuario o administrador
    do{
        printf("\nIntroduzca su perfil de usuario (Administrado:a, usuario:u): ");
        fflush(stdin);
        scanf("%c",&aux_admin);
    }while(aux_admin!='a'&&aux_admin!='A'&&aux_admin!='u'&&aux_admin!='U');
    if(aux_admin=='a'||aux_admin=='A'){
        //Si dice que es administrador, debera introducir la clave del administrador
        printf("\nIntroduce la clave de administrador: ");
        fflush(stdin);
        gets(admin);
        if(strcmp(admin,"admin2023ESI")!=0){
            //Si introduce la clave mal, entonces se le pone como usuario
            printf("\nIncorrecto. Se te pondr� como usuario normal\n");
            strcpy(usu[(*tam)].Perfil_usuario,"usuario");
        }
        else{
            printf("\nCorrecto\n");
            strcpy(usu[(*tam)].Perfil_usuario,"administrador");
        }
    }
    else
        strcpy(usu[(*tam)].Perfil_usuario,"usuario");
    //Si el tama�o del vector es 0, no hay nicknames con los que comparar, hacemos que se introduzca directamente
    if((*tam)==0){
        //Introducimos nombre de usuario
        printf("\nIntroduzca el nombre de usuario (5 caracteres max): ");
        fflush(stdin);
        gets(usu[(*tam)].Usuario);
    }
    else{
        do{
            nickname=0;
            //Introducimos nombre de usuario
            printf("\nIntroduzca el nombre de usuario (5 caracteres max): ");
            fflush(stdin);
            gets(aux_nickname);
            //Comprobamos que el nickname introducido no exista
            nickname=comprobar_nickname(usu,(*tam),aux_nickname);
            if(nickname==1)
                printf("\nEse usuario no esta disponible. Intente con otro\n");
        }while(nickname==1);
        strcpy(usu[(*tam)].Usuario,aux_nickname);
    }
    //Introducimos contrase�a
    printf("\nIntroduzca la contrase�a (8 caracteres maximo): ");
    fflush(stdin);
    gets(usu[(*tam)].Contrasenna);
    //Aumentamos tama�o del vector recibido en 1
    (*tam)++;
    //Realizamos un aumento del tama�o del vector en 1 elemento con realloc
    usu=(usuario*)realloc(usu,((*tam)+1)*sizeof(usuario));
    puts("\nUsuario creado con exito\n");
    return usu;
}

coches* crearVehiculo(coches *coche,int *tam,char *id_usu){
    int int_auxmat,plazas;
    char auxmat[8];
    //Si no hay vehiculos registrados, la matricula se puede introducir directamente
    if((*tam)==0){
        //Introducimos la matricula del vehiculo
        printf("\nIntroduzca la matricula del vehiculo (7 caracteres): ");
        fflush(stdin);
        gets(coche[(*tam)].id_mat);

    }
    else{
        do{
            int_auxmat=0;
            printf("\nIntroduzca la matricula del vehiculo (7 caracteres): ");
            fflush(stdin);
            gets(auxmat);
            //Comprobamos que la matricula introducida no exista
            int_auxmat=comprobar_coche(coche,(*tam),auxmat);
            if(int_auxmat==1)
                printf("\nMatricula ya existente\n");
        }while(int_auxmat==1);
        strcpy(coche[(*tam)].id_mat,auxmat);
    }
    strcpy(coche[(*tam)].id_usuario,id_usu);
    //Pedimos el numero de plazas comprobando que sea mayor que 1 y menor que 10
    do{
        printf("\nIntroduce el nuevo numero de plazas (sin contar la del conductor): ");
        fflush(stdin);
        scanf("%i",&plazas);
    }while(plazas<1||plazas>=10);
    coche[(*tam)].Num_plazas=plazas;
    //Introducimos la descripcion del vehiculo
    printf("\nIntroduzca la descripcion del vehiculo (50 caracteres max): ");
    fflush(stdin);
    gets(coche[(*tam)].Desc_veh);
    //Aumentamos el tama�o del vector
    (*tam)++;
    //Aumentamos el tama�o del vector realizando un realloc de un elemento
    coche=(coches*)realloc(coche,((*tam)+1)*sizeof(coches));
    puts("\nVehiculo creado con exito\n");
    return coche;
}

viajes* crearViajes(viajes *viaj,int *tam,char *mat,int plazas, char*id_aux){
    int diaa,mess,anno,correcto;
    char opcion[7],vect_aux_id[7],dia[3],mes[3],anio[5],horaa[3],min[3],aux_hora[3],aux_min[3];
    //Si no hay viajes registrados, entonces el id que metera sera 000001
    if((*tam)==0)
        strcpy(vect_aux_id,"000001");
    else
        //Cuando ya hay viajes, llamamos a la funcion que nos asigna un id disponible
        asignar_id_viaje(viaj,(*tam),vect_aux_id);
    strcpy(viaj[(*tam)].id_viaje,vect_aux_id);
    //Copiamos en la cadena recibida (id_aux), el id del viaje que se nos ha asignado
    strcpy(id_aux,vect_aux_id);
    //Copiamos en id_mat la matricula recibida como parametro
    strcpy(viaj[(*tam)].id_mat,mat);
    //Copiamos en el parametro plazas libres el numero de plazas del vehiculo (recibido como parametro)
    viaj[(*tam)].plazas_libres=plazas;
    do{
        correcto=0;
        printf("\nIntroduzca el d�a del viaje en formato DD: ");
        fflush(stdin);
        scanf("%s",dia);
        printf("\nIntroduzca el mes en formato MM: ");
        fflush(stdin);
        scanf("%s",mes);
        printf("\nIntroduzca el a�o en formato AAAA: ");
        fflush(stdin);
        scanf("%s",anio);
        //Comprobamos si la fecha introducida es correcta
        correcto=comprobarFecha(dia,mes,anio);
        //Si la fecha no es correcta o ya ha pasado, que de un mensaje y repita el bucle
        if(correcto==0)
            printf("\nIntroduce una fecha valida y acorde a la actual\n");
    }while(correcto==0);
    diaa=atoi(dia);
    mess=atoi(mes);
    anno=atoi(anio);
    viaj[(*tam)].F_inic.dia=diaa;
    viaj[(*tam)].F_inic.mes=mess;
    viaj[(*tam)].F_inic.anio=anno;
    //Si ha devuelto 1 significa que la fecha es la de hoy, y la hora se comprobara con la actual
    if(correcto==1){
        //Introducimos la hora de salida
        do{
            correcto=0;
            printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
            fflush(stdin);
            scanf("%s",horaa);
            printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
            fflush(stdin);
            scanf("%s",min);
            //Comprobamos si la hora es correcta con respecto a la actual
            correcto=comprobarHora_actual(horaa,min);
            if(correcto==0)
                printf("\nIntroduce una hora valida y acorde a la actual\n");
        }while(correcto!=1);
        //Introducimos los datos convirtiendo de cadena a entero para guardarlo en el vector
        viaj[(*tam)].H_inic.minu=atoi(min);
        viaj[(*tam)].H_inic.hora=atoi(horaa);
        //Introducimos la hora de llegada
        do{
            correcto=0;
            printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
            fflush(stdin);
            scanf("%s",horaa);
            printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
            fflush(stdin);
            scanf("%s",min);
            //Pasamos a cadena la hora de inicio para pasarlo a la funcion de a continuacion
            sprintf(aux_hora,"%i",viaj[(*tam)].H_inic.hora);
            sprintf(aux_min,"%i",viaj[(*tam)].H_inic.minu);
            //Comprobamos si la hora de llegada es mayor que la de salida
            if(comprobar_hora2_menor_hora1(aux_hora,aux_min,horaa,min)==1){
                //Comprobamos si la hora es correcta con respecto a la actual
                correcto=comprobarHora_actual(horaa,min);
                if(correcto==0)
                    printf("\nIntroduce una hora valida y acorde a la actual\n");
            }
            else
                printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
        }while(correcto!=1);
        //Pasamos de cadena a entero para introducirlo en el vector
        viaj[(*tam)].H_fin.minu=atoi(min);
        viaj[(*tam)].H_fin.hora=atoi(horaa);
    }
    //Si la fecha no es la actual, entonces tiene que ser una posterior y la hora debe comprobarse unicamente como correcta o no
    else{
        //Introducimos la hora de salida
        do{
            correcto=0;
            printf("\nIntroduce la hora de salida en formato HH (solo las horas): ");
            fflush(stdin);
            scanf("%s",horaa);
            printf("\nIntroduce la hora de salida en formato MM (solo los minutos): ");
            fflush(stdin);
            scanf("%s",min);
            //Comprobamos si la hora es correcta
            correcto=comprobar_hora(horaa,min);
            if(correcto==0)
                printf("\nIntroduce una hora valida\n");
        }while(correcto==0);
        //Pasamos de cadena a entero para introducirlo en el vector
        viaj[(*tam)].H_inic.minu=atoi(min);
        viaj[(*tam)].H_inic.hora=atoi(horaa);
        //Introducimos la hora de llegada
        do{
            correcto=0;
            printf("\nIntroduce la hora de llegada en formato HH (solo las horas): ");
            fflush(stdin);
            scanf("%s",horaa);
            printf("\nIntroduce la hora de llegada en formato MM (solo los minutos): ");
            fflush(stdin);
            scanf("%s",min);
            //Pasamos a cadena la hora de inicio para pasarlo a la funcion de a continuacion
            sprintf(aux_hora,"%i",viaj[(*tam)].H_inic.hora);
            sprintf(aux_min,"%i",viaj[(*tam)].H_inic.minu);
            //Comprobamos si la hora de llegada es mayor que la de salida
            if(comprobar_hora2_menor_hora1(aux_hora,aux_min,horaa,min)==1){
                //Comprobamos si la hora es correcta con respecto a la actual
                correcto=comprobar_hora(horaa,min);
                if(correcto==0)
                    printf("\nIntroduce una hora valida y acorde a la actual\n");
            }
            else
                printf("\nLa hora de llegada no tiene sentido respecto de la de salida\n");
        }while(correcto==0);
        //Pasamos de cadena a entero para introducirlo en el vector
        viaj[(*tam)].H_fin.minu=atoi(min);
        viaj[(*tam)].H_fin.hora=atoi(horaa);
    }
    do{
        //Pedimos que introduzca si el viaje es de ida o vuelta, y si no introduce alguna de las dos, el bucle se repite
        correcto=0;
        printf("\nIntroduce si el viaje es de ida o de vuelta (poner ida o vuelta): ");
        fflush(stdin);
        gets(opcion);
        if(strcmp(opcion,"ida")!=0&&strcmp(opcion,"vuelta")!=0){
            printf("\nPalabra introducida incorrecta. Escribela tal y como aparece en la reclamacion del dato\n");
            correcto=1;
        }
    }while(correcto==1);
    strcpy(viaj[(*tam)].id_vuelta,opcion);
    //Pedimos que introduzca el importe del viaje
    printf("\nIntroduce el importe total del viaje: ");
    scanf("%f",&viaj[(*tam)].importe);
    //Ponemos automaticamente el viaje como estado abierto al acabarse de crear
    strcpy(viaj[(*tam)].estado,"abierto");
    //Aumentamos el tama�o del vector
    (*tam)++;
    //Realizamos un aumento de memoria de 1 elemento en el vector
    viaj=(viajes*)realloc(viaj,((*tam)+1)*sizeof(viajes));
    printf("\nViaje creado con exito\n");
    return viaj;
}

pasos* crearPasos(pasos *pas,int *tam,char *id_viaj){
    int opcion;
    char opcion_char;
    do{
        //Damos al usuario distintas opciones de localidades a elegir
        do{
            printf("\nElige las ciudades por las que estas dispuesto a pasar (sin incluir la ciudad a la que te diriges)\n");
            puts("1. Cadiz");
            puts("2. Puerto Real");
            puts("3. San Fernando");
            puts("4. Chiclana");
            puts("5. Jerez");
            puts("6. Puerto de Santa Maria");
            puts("7. Barbate");
            puts("8. Conil");
            puts("9. Rota");
            puts("10. Algeciras");
            fflush(stdin);
            scanf("%i",&opcion);
            if(opcion>10||opcion<1)
                printf("\nIntroduce una opcion valida\n");
        }while(opcion>10||opcion<1);
        switch(opcion){
            //Segun sea la opcion, se copia la localidad indicada
            case 1:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Cadiz");
                break;
            case 2:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Puerto Real");
                break;
            case 3:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"San Fernando");
                break;
            case 4:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Chiclana");
                break;
            case 5:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Jerez");
                break;
            case 6:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Puerto Santa Maria");
                break;
            case 7:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Barbate");
                break;
            case 8:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Conil");
                break;
            case 9:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Rota");
                break;
            case 10:
                strcpy(pas[*tam].id_viaje,id_viaj);
                strcpy(pas[*tam].poblacion,"Algeciras");
                break;
        }
        //Aumentamos el tama�o del vector
        (*tam)++;
        //Realizamos un aumento del tama�o del vector en 1 elemento
        pas=(pasos*)realloc(pas,((*tam)+1)*sizeof(pasos));
        //Comprobamos que el usuario no quiera pasar por mas localidades
        printf("\nQuieres a�adir un paso mas? (S/N): ");
        fflush(stdin);
        scanf("%c",&opcion_char);
    }while(opcion_char=='S'||opcion_char=='s');
    return pas;
}

void unirse_viaje(viajes *viaj,pasos *pas,coches *coch,int tam_viaj,int tam_pas,int tam_coch,char *localidad){
    int i,encontrado=0,j,pos;
    char mat[8],opcion,aux_id[7];
    //Si no hay viajes registrados entonces se da un mensaje directo por pantalla
    if(tam_viaj>0){
        //Damos la opcion de que se listen los viajes que pasan por la localidad del usuario
        do{
            printf("\nQuieres ver los viajes que en concreto van/inician o pasan por tu localidad?: ");
            fflush(stdin);
            scanf("%c",&opcion);
            if(opcion!='s'&&opcion!='n')
                printf("\nIntroduce una opcion valida\n");
        }while(opcion!='s'&&opcion!='n');
        //Si ha dicho si, listamos todos los viajes que pasan por su localidad
        if(opcion=='s'){
            printf("-----------------------------------------------------------------------\n");
            printf("La lista de viajes registrados que pasan por tu localidad y cumple con tus requisitos es: \n\n");
            //Recorremos el vector, y si coincide el parametro ida o vuelta y coincide la localidad, aparecen por pantalla
            for(i=0;i<tam_viaj;i++){
                for(j=0;j<tam_pas;j++)
                    if(strcmp(viaj[i].id_viaje,pas[j].id_viaje)==0){
                        if(strcmp(pas[j].poblacion,localidad)==0){
                            printf("%s-%s-%.2i/%.2i/%i-%.2i:%.2i-%.2i:%.2i-%i-%s-%.2f-%s",viaj[i].id_viaje,viaj[i].id_mat,viaj[i].F_inic.dia,viaj[i].F_inic.mes,viaj[i].F_inic.anio,viaj[i].H_inic.hora,viaj[i].H_inic.minu,viaj[i].H_fin.hora,viaj[i].H_fin.minu,viaj[i].plazas_libres,viaj[i].id_vuelta,viaj[i].importe,viaj[i].estado);
                            printf("\n\n");
                            encontrado=1;
                        }
                    }
            }
            printf("\n------------------------------------------------------------------------");
            //Si no se ha encontrado ningun viaje con esas especificaciones, se da un mensaje
            if(encontrado==0)
                printf("\nNo hay viajes con esas especificaciones\n");
        }
        //Si el usuario ha dicho que no, listamos todos los viajes
        else
            listar_viajes(viaj,tam_viaj);
        encontrado=0;
        //Pedimos el id del viaje
        printf("\nIntroduce el id del viaje que quieres realizar: ");
        fflush(stdin);
        gets(aux_id);
        //Comprobamos que el id exista
        for(i=0;i<tam_viaj;i++)
            if(strcmp(viaj[i].id_viaje,aux_id)==0){
                encontrado=1;
                pos=i;
                strcpy(mat,viaj[i].id_mat);
                //Si el id existe, comprobaremos que no se ha
                for(j=0;j<tam_coch;j++)
                    if(strcmp(viaj[i].id_mat,coch[j].id_mat)==0)
                        //Si el numero de plazas libres es igual al de plazas originales, salvaguardamos el importe para futuras actualizaciones del mismo
                        if(viaj[i].plazas_libres==coch[j].Num_plazas)
                            aux_importe=viaj[i].importe;
            }
        //Si no se ha encontrado o no esta en los estados abierto o iniciado, no dejara unirse al viaje
        if(encontrado==0||(strcmp(viaj[pos].estado,"abierto")!=0&&strcmp(viaj[pos].estado,"iniciado")!=0))
            printf("\nNo se ha encontrado un viaje con ese id y que cumpla tus requisitos o ese viaje ya no esta disponible\n");
        else{
            //Actualizamos numero de plazas libres
            viaj[pos].plazas_libres-=1;
            //Actualizamos el importe del viaje
            viaj[pos].importe=precio_actualizado(coch,tam_coch,viaj[pos].plazas_libres,aux_importe,mat);
            //Si ya no quedan plazas libres ponemos el estado como cerrado
            if(viaj[pos].plazas_libres==0)
                strcpy(viaj[pos].estado,"cerrado");
            printf("\nSe ha unido correctamente y la informacion del viaje se ha actualizado\n");
        }
    }
    else
        printf("\nNo hay viajes disponibles en este momento\n");
}
