//IMPORTANTE: ESTE PROGRAMA ESTA PENSADO PARA QUE SIEMPRE HAGA UN MALLOC DE 1 ELEMENTO, ES POR ESO QUE TODO EL CODIGO ESTA ADAPTADO PARA ELLO (LOS REALLOC SE HACEN AL FINAL DE LAS FUNCIONES QUE LO NECESITEN)

#include <stdio.h>
#include <stdlib.h>

#include "cargar.h"

void cargarUsuario(usuario **usu, int *n) {
    int tam=0;
    FILE *f;
    //Trabajamos con nuevo para poder trabajar con un solo puntero, no dos
    usuario *nuevo;
    //hacemos reserva de memoria dinamica (1 elemento), comprobando que no nos da error
    //IMPORTANTE: ESTE PROGRAMA ESTA PENSADO PARA QUE SIEMPRE HAGA UN MALLOC, ES POR ESO QUE TODO EL CODIGO ESTA ADAPTADO PARA ELLO (LOS REALLOC SE HACEN AL FINAL DE LAS FUNCIONES QUE LO NECESITEN)
    if((nuevo=malloc(sizeof(usuario)))==NULL)
        printf("No se ha podido realizar la reserva de memoria");
    else{
        f=fopen("Usuarios.txt","r");
        //Comprobamos si el fichero se ha abierto correctamente
        if (f==NULL)
            printf("No se pudo abrir el archivo usuarios.txt\n");
        else {
            //Leemos desde el fichero los datos correspondientes mientras que esa lectura sea igual al numero de elementos totales
            while (fscanf(f,"%[^-]-%[^-]-%[^-]-%[^-]-%[^-]-%[^\n]\n",nuevo[tam].id_usuario, nuevo[tam].nomb_usuario, nuevo[tam].Localidad, nuevo[tam].Perfil_usuario, nuevo[tam].Usuario, nuevo[tam].Contrasenna)==6) {
                tam++;
                //Hacemos un realloc para aumentar el tama�o del vector nuevo en un elemento
                nuevo=realloc(nuevo,(tam+1)*sizeof(usuario));
            }
            fclose(f);
        }
    }
    //Asignamos el vector nuevo al recibido
    *usu=nuevo;
    //Asignamos al tama�o del vector el tama�o que ha tenido el auxiliar
    *n=tam;
}

void cargarVehiculo(coches **coch,int *n){
    int tam=0;
    FILE *f;
    //Utilizamos otro vector como auxiliar sobre el que trabajamos para trabajar con solo un puntero
    coches *nuevo;
    //Realizamos un malloc del vector de 1 elemento y comprobamos si es distinto de NULL
    if((nuevo=malloc(sizeof(coches)))==NULL)
        printf("No se ha podido realizar la reserva de memoria");
    else{
        f=fopen("Vehiculos.txt","r");
        //Comprobamos si el fichero se ha abierto correctamente
        if (f==NULL)
            printf("No se pudo abrir el archivo usuarios.txt\n");
        else {
            //Leemos desde el fichero los datos correspondientes mientras que esa lectura sea igual al numero de elementos totales
            while (fscanf(f,"%[^-]-%[^-]-%i-%[^\n]\n",nuevo[tam].id_mat, nuevo[tam].id_usuario,&nuevo[tam].Num_plazas,nuevo[tam].Desc_veh)==4){
                tam++;
                //Aumentamos el tama�o del vector nuevo en un elemento
                nuevo=realloc(nuevo,(tam+1)*sizeof(coches));
            }
            fclose(f);
        }
    }
    //Asignamos el vector auxiliar al que recibimos
    *coch=nuevo;
    //Asignamos al tama�o del vector el tama�o que ha tenido el auxiliar
    *n=tam;
}

void cargarViajes(viajes **viaj,int *n){
    int tam=0;
    FILE *f;
    //Utilizamos otro vector como auxiliar sobre el que trabajamos para trabajar con solo un puntero
    viajes *nuevo;
    //Realizamos un malloc del vector de 1 elemento y comprobamos si es distinto de NULL
    if((nuevo=malloc(sizeof(viajes)))==NULL)
        printf("No se ha podido realizar la reserva de memoria");
    else{
        f=fopen("Viajes.txt","r");
        //Comprobamos si el fichero se ha abierto correctamente
        if (f==NULL)
            printf("No se pudo abrir el archivo usuarios.txt\n");
        else {
            //Leemos desde el fichero los datos correspondientes mientras que esa lectura sea igual al numero de elementos totales
            while (fscanf(f,"%[^-]-%[^-]-%i/%i/%i-%i:%i-%i:%i-%i-%[^-]-%f-%[^\n]\n",nuevo[tam].id_viaje,nuevo[tam].id_mat,&nuevo[tam].F_inic.dia,&nuevo[tam].F_inic.mes,&nuevo[tam].F_inic.anio,&nuevo[tam].H_inic.hora,&nuevo[tam].H_inic.minu,&nuevo[tam].H_fin.hora,&nuevo[tam].H_fin.minu,&nuevo[tam].plazas_libres,nuevo[tam].id_vuelta,&nuevo[tam].importe,nuevo[tam].estado)==13){
                tam++;
                //Aumentamos el tama�o del vector nuevo en un elemento
                nuevo=realloc(nuevo,(tam+1)*sizeof(viajes));
            }
            fclose(f);
        }
    }
    //Asignamos el vector auxiliar al que recibimos
    *viaj=nuevo;
    //Asignamos al tama�o del vector el tama�o que ha tenido el auxiliar
    *n=tam;
}

void cargarPasos(pasos **pas,int *n){
    int tam=0;
    FILE *f;
    //Utilizamos otro vector como auxiliar sobre el que trabajamos para trabajar con solo un puntero
    pasos *nuevo;
    //Realizamos un malloc del vector de 1 elemento y comprobamos si es distinto de NULL
    if((nuevo=malloc(sizeof(pasos)))==NULL)
        printf("No se ha podido realizar la reserva de memoria");
    else{
        f=fopen("Pasos.txt","r");
        //Comprobamos si el fichero se ha abierto correctamente
        if (f==NULL)
            printf("No se pudo abrir el archivo usuarios.txt\n");
        else {
            //Leemos desde el fichero los datos correspondientes mientras que esa lectura sea igual al numero de elementos totales
            while (fscanf(f,"%[^-]-%[^\n]\n",nuevo[tam].id_viaje,nuevo[tam].poblacion)==2){
                tam++;
                //Aumentamos el tama�o del vector nuevo en un elemento
                nuevo=realloc(nuevo,(tam+1)*sizeof(pasos));
            }
            fclose(f);
        }
    }
    //Asignamos el vector auxiliar al que recibimos
    *pas=nuevo;
    //Asignamos al tama�o del vector el tama�o que ha tenido el auxiliar
    *n=tam;
}
