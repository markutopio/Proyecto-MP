//Este modulo se encarga de borrar los datos de los que el usuario tenga acceso para ello

#ifndef _BORRAR_H_
#define _BORRAR_H_

#include "datos.h"


//Cabecera: void borrarVehiculo(coches *,int *,char*)
//Precondicion: recibe un vector de tipo coches, un puntero a entero (tama�o del vector), y una cadena de caracteres (id del usuario)
//Postcondicion: elimina del vector el vehiculo que elija el usuario y que este asociado a su id, actualizando el tama�o del mismo
void borrarVehiculo(coches **,int *,char*);


#endif // _BORRAR_H_
