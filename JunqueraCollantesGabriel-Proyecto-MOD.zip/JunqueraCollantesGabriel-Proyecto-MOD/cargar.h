//Este modulo se encarga de cargar desde los ficheros asociados al programa toda la informacion que haya presente

#ifndef _CARGAR_H_
#define _CARGAR_H_

#include "datos.h"

//Cabecera: void cargarUsuario(usuario **,int *)
//Precondicion: recibe un vector de tipo usuario y un puntero a entero
//Postcondicion: carga los usuarios que haya en Usuarios.txt en el vector que recibe y modifica el entero que recibe como 2� parametro
void cargarUsuario(usuario **,int *);


//Cabecera: void cargarVehiculo(coches **,int *)
//Precondicion: recibe un vector de tipo coches y un puntero a entero
//Postcondicion: carga los usuarios que haya en Vehiculos.txt en el vector que recibe y modifica el entero que recibe como 2� parametro
void cargarVehiculo(coches **,int *);


//Cabecera: void cargarVehiculo(coches **,int *)
//Precondicion: recibe un vector de tipo pasos y un puntero a entero
//Postcondicion: carga los usuarios que haya en Pasos.txt en el vector que recibe y modifica el entero que recibe como 2� parametro
void cargarPasos(pasos **,int *);


//Cabecera: void cargarViajes(viajes **,int *)
//Precondicion: recibe un vector de tipo viajes y un puntero a entero
//Postcondicion: carga los usuarios que haya en Viajes.txt en el vector que recibe y modifica el entero que recibe como 2� parametro
void cargarViajes(viajes **,int *);

#endif // _CARGAR_H_
