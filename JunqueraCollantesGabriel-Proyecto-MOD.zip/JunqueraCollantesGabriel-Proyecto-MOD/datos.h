//Este modulo almacena todas las estructuras de datos necesarias para el proyecto

#ifndef _DATOS_H_
#define _DATOS_H_

typedef struct{
    int dia,mes,anio;
}fechas;

typedef struct{
    int hora,minu;
}horas;

typedef struct{
    char id_usuario[5];
    char nomb_usuario[21];
    char Localidad[21];
    char Perfil_usuario[14];
    char Usuario[6];
    char Contrasenna[9];
}usuario;

typedef struct{
    char id_mat[8];
    char id_usuario[5];
    int Num_plazas;
    char Desc_veh[51];
}coches;

typedef struct{
    char id_viaje[7];
    char id_mat[8];
    fechas F_inic;
    horas H_inic;
    horas H_fin;
    int plazas_libres;
    char id_vuelta[7];
    float importe;
    char estado[12];
}viajes;

typedef struct{
    char id_viaje[7];
    char poblacion[21];
}pasos;


#endif // _DATOS_H_
