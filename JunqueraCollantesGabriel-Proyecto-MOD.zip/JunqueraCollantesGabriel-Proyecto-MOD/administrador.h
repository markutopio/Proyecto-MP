//Este modulo se encarga de definir y desarrollar diversar funciones para el administrador del sistema

#ifndef _ADMINISTRADOR_H_
#define _ADMINISTRADOR_H_


#include "administrar.h"  //incluimos administrar por haber diversas funciones que se utilizaran en el mismo, como alguna de comprobar

//Cabecera: void listar_usuarios_admin(usuario *,int)
//Precondicion: recibe un vector de tipo usuario y un entero (su tama�o)
//Postcondicion: Lista en pantalla todos los elementos del vector
void listar_usuarios_admin(usuario *,int);


//Cabecera: void listar_vehiculos_admin(coches *, int)
//Precondicion: recibe un vector de tipo coches y un entero (su tama�o)
//Postcondicion: Lista en pantalla todos los elementos del vector
void listar_vehiculos_admin(coches *, int);


//Cabecera: void modificar_usuario_admin(usuario *,int,int)
//Precondicion: recibe un vector de tipo usuario, un entero (su tama�o) y otro entero (eleccion procedente del main para el switch)
//Postcondicion: modifica la informacion del usuario que se indique dentro de la funcion
void modificar_usuario_admin(usuario *,int,int);


//Cabecera: void modificar_vehiculo_admin(coches *,int,int)
//Precondicion: recibe un vector de tipo coches, un entero (su tama�o) y otro entero (eleccion procedente del main para el switch)
//Postcondicion: modifica la informacion del vehiculo que se indique dentro de la funcion
void modificar_vehiculo_admin(coches *,int,int);


//Cabecera: void borrarUsuario_admin(usuario **, int *)
//Precondicion: recibe un vector de tipo usuario y un puntero a entero (su tama�o)
//Postcondicion: borra el usuario que se especifique dentro de la funcion y modifica el tama�o del vector
void borrarUsuario_admin(usuario **, int *);


//Cabecera: void borrarVehiculo_admin(coches **, int *)
//Precondicion: recibe un vector de tipo coches y un puntero a entero (su tama�o)
//Postcondicion: borra el vehiculo que se especifique dentro de la funcion y modifica el tama�o del vector
void borrarVehiculo_admin(coches **, int *);


//Cabecera: void borrarViaje_admin(coches *,viajes **, int *,int, char *)
//Precondicion: recibe un vector de tipo coches, un vector de tipo viajes, un puntero a entero (tama�o del vector viajes), un entero (tama�o del vector vehiculos) y una cadena, donde se retornara el id del viaje para despues borrar los pasos
//Postcondicion: borra el viaje que se especifique dentro de la funcion y modifica el tama�o del vector viajes
void borrarViaje_admin(coches *,viajes **, int *,int, char *);


//Cabecera: void borrarPasos_admin(pasos **, int *, char *)
//Precondicion: recibe un vector de tipo pasos, un puntero a entero (su tama�o) y una cadena de caracteres (el id del viaje que se ha borrado y cuyos pasos se deben borrar)
//Postcondicion: borra los pasos asociados al viaje eliminado y modifica el tama�o del vector
void borrarPasos_admin(pasos **, int *, char *);


//Cabecera: void modificar_viajes_admin(coches *,viajes *,int,int,int)
//Precondicion: recibe un vector de tipo coches, un vector de tipo viajes, y tres enteros (tama�o de los vectores y la eleccion procedente del main para el switch)
//Postcondicion: modifica el viaje especificado dentro de la funcion
void modificar_viajes_admin(coches *,viajes *,int,int,int);

#endif // _ADMINISTRADOR_H_
