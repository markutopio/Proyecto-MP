#ifndef _CARGA_H_
#define _CARGA_H_

#include "datos.h"

//En primer lugar, hacemos una lista declarando los tipos de datos que usaremos//
//Y luego, declararemos tambi�n unos punteros que apuntan hacia vectores de distintos datos//

int nUsuarios;//N�mero de usuarios en usuarios.txt//
int nAlumnos;//N�mero de alumnos en alumnos.txt//
int nMaterias;//N�mero de administradores en administradores.txt//
int nMatriculas;//N�mero de matriculas en matriculas.txt//
int nCalificaciones;//N�mero de calificaciones en calificaciones.txt//
int nHorarios;//N�mero de horarios en horarios.txt//


int carga();
int cargaUsuarios(usuarios **,int *);//usuarios ** significa que apunta al interior del inicio de un vector, y la posici�n//
// del vector ser� la que nos d� con el int * para llegar al usuario correspondiente almacenado en dicha posici�n del vector//
int cargaAlumnos(alumnos **,int *);
int cargaMaterias(materias **,int *);
int cargaMatriculas(matriculas **,int *);
int cargaCalificaciones(calificaciones **,int *);
int cargaHorarios(horarios **,int *);

void borrar_saltos(char *,int);

#endif
