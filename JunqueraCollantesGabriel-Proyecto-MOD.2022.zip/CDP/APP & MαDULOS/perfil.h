#ifndef _PERFIL_
#define _PERFIL_

#include "carga.h"
#include "datos.h"
#include "admin.h"
#include "profesor.h"

void perfil (int tipo, int i_usuario);

static void menu_admin (int i_usuario);
static void menu_profe (int i_usuario);

#endif
