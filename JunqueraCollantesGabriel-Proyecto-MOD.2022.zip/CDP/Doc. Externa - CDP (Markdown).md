# CUADERNO DIGITAL DEL PROFESOR - CDP

## Índice

1. [Documentación de Usuario](##Documentación de Usuario)

   1.2. [Descripción Funcional](###Descripción Funcional)

   1.2. [Tecnología](###Tecnología)

   1.3. [Manual de Instalación](###Manual de Instalación)

   1.4. [Acceso al Sistema](###Acceso al Sistema)

   1.5. [Manual de Referencia](###Manual de Referencia)

   ​	1.5.1. [*Menú Administrador](####*Menú Administrador)

   ​	1.5.2. [*Menú Profesor](####*Menú Profesor)

2. [Documentación del Sistema](##[Documentación del Sistema]())

   2.1. [Módulos Implementados y Subproblemas](###Módulos Implementados y Subproblemas)

   2.2. [Pruebas de Unidad](###Pruebas de Unidad)
   
   ​	2.2.1. [Módulo Cuaderno](####·Módulo Cuaderno)
   
   ​	2.2.2. [Módulo Perfil](####·Módulo Perfil)
   
   ​	2.2.3. [Módulo Profesor](####·Módulo Profesor)
   
   ​	2.2.4. [Módulo Administrador](####·Módulo Administrador)
   
   2.3. [Pruebas del Conjunto de Rutas Básicas (Caja Blanca)](###Pruebas del Conjunto de Rutas Básicas (Caja Blanca))





## Documentación de Usuario

### Descripción Funcional

El programa ha sido diseñado para poder llevar, en formato digital,  el control académico de todo el alumnado, como los datos del estudiante y sus calificaciones. También se usará para almacenar las materias y grupos que imparte el profesorado, así como los horarios, etc. El sistema dispondrá de dos perfiles de usuarios: 

• Un perfil de profesor, con acceso a los datos personales de los alumnos a los que imparte clases, calificaciones, etc.

• Un perfil administrador, que realizará tareas de configuración del programa tales como tratamiento de alumnos, usuarios, materias, etc.

### Tecnología

Para el desarrollo del programa se ha empleado Dev-C++ y Code::Blocks. El documento ha sido escrito mediante Typora. A continuación se adjuntan los enlaces a los softwares utilizados: 

-  [Code::Blocks](https://www.codeblocks.org/)
- [Dev-C++](https://www.bloodshed.net/)
- [Typora](https://typora.io/)

### Manual de Instalación

Para instalarlo en su ordenador solo debe descargar el archivo .zip, descomprimirlo y ejecutar el .exe. 

Si desea compilarlo tan solo debe descargar Dev-C++ o Code::Blocks y abrir el proyecto (.dev).

### Acceso al Sistema

El administrador por defecto es el el siguiente: 001-Jose Antonio Castro-administrador-admin-jas12345

A la hora de iniciar el programa le pedirá un usuario y una contraseña, y deberá introducir:

Usuario: admin

Contraseña: jas12345

![image-20220417201839930](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220417201839930.png)

Una vez haya accedido tendrá total libertad al menú administrador.

Por otra parte, el profesor por defecto es: 002-Pilar Lopez-profesor-profe-pl123456

Análogamente, accederá al menú profesor.

### Manual de Referencia

**<u>Posible Error Frecuente</u>**: Ha de tenerse en cuenta, que a la hora de introducir los datos que solicite el programa, estos han de corresponderse totalmente con lo que se encuentra registrado en los ficheros, esto es, respetar las mayúsculas y el número de caracteres. En cualquier caso, si el usuario se equivoca a la hora de introducir dichos datos, el programa le preguntará si desea volver a intentarlo, en caso que así lo desee.

##### ***Menú Administrador**

![image-20220417204622687](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220417204622687.png)

Una vez hayamos accedido como administrador se nos presentarán 5 opciones:

- Usuarios. Con esta opción accedemos a la parte de gestión de usuarios, pudiendo elegir entre las opciones que se nos presentan.

  ![image-20220417205319107](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220417205319107.png)

  - Agregar usuarios. Solicita la información necesaria para añadir un nuevo usuario al sistema, entre ellas se encuentran:

    - ID (3 dígitos): No debe coincidir con alguno ya existente.
    - Nombre del usuarios (20 caracteres máximo)
    - Tipo de perfil (administrador o profesor)
    - Usuario o login (5 caracteres máximo): No debe coincidir con alguno ya existente.
    - Contraseña (8 caracteres máximo)

    Tras ello, pregunta al final si desea crearlo.

  - Eliminar usuarios. Solicita el ID del usuario que desee eliminar, tras ello, deberá confirmarlo.

  - Modificar usuarios. Solicita el login del usuario que desea modificar, tras ello, le permite elegir que campo desea cambiar.

  - Listar usuarios. Muestra todos los usuarios que se encuentran registrados en el sistema.

    

- Alumnos. Con esta opción accedemos a la parte de gestión de alumnos, pudiendo elegir entre las opciones que se nos presentan.

  ![image-20220417211005101](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220417211005101.png)

  - Agregar alumnos.  Solicita la información necesaria para añadir un nuevo alumno al sistema:
  
    - ID (6 dígitos): No debe coincidir con alguno ya en uso.
  
    - Nombre del alumno (20 caracteres máximo)
  
    - Dirección del alumno (30 caracteres máximo)
  
    - Localidad del alumno (30 caracteres máximo)
  
    - Curso (30 caracteres máximo)
  
    - Grupo (10 caracteres máximo)
  
      Por último, pide la confirmación del usuario.
  
  - Eliminar alumnos. Solicita el ID del alumno que desea eliminar, tras ello, deberá confirmarlo.
  
  - Modificar alumnos. Solicita el  ID del alumno que desea modificar, tras ello, le permite elegir que campo desea cambiar. Con la opción 7 se accede al menú de matrículas del alumno .
  
    ![image-20220418194317570](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418194317570.png)
  
    - Matrículas. Muestra las materias en las que el alumno introducido previamente se encuentra matriculado y permite gestionarlas, presentando las siguientes opciones:
  
      ![image-20220418200151242](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418200151242.png)
  
      - Agregar matrícula. Solicita el ID de la materia a la que quiere matricular. No se puede encontrar ya matriculado en dicha materia.
      - Eliminar matrícula. Solicita el ID de la materia en la que el alumno se encuentra matriculado, tras ello pide confirmación.
      - Modificar matricula. Solicita el ID de la materia que desea modificar y permite cambiar dicha materia.
  
  - Listar alumnos. Muestra todos los alumnos que se encuentran registrados en el sistema.

- Materias. Con esta opción accedemos a la parte de gestión de materias, pudiendo elegir entre las opciones que se nos presentan.

  ![image-20220418184642357](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418184642357.png)

  - Agregar materias.  Solicita la información necesaria para añadir una nueva materia al sistema:
    - ID (4 dígitos): No debe coincidir con alguna ya en uso.
    - Nombre de la materia (50 caracteres máximo)
    - Abreviatura (3 caracteres)
  - Eliminar materias. Solicita el ID de la materia que desea eliminar, tras ello, deberá confirmarlo.
  - Modificar materias. Solicita el  ID de la materia que desea modificar, tras ello, le permite elegir que campo desea cambiar.
  - Listar materias. Muestra todos las materias que se encuentran registradas en el sistema.

- Horarios. Con esta opción accedemos a la parte de gestión de horarios de los profesores, pudiendo elegir entre las opciones que se nos presentan.

  ![image-20220418185308746](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418185308746.png)

  - Agregar hora a un profesor. Solicita el ID del profesor (ID usuario) al que desea añadirle un nuevo horario, luego solicita la información necesaria para crear un nuevo horario:

    - Día: Deberá ser un nº del 1 (lunes) al 5 (viernes).
    - Hora: Deberá ser un nº del 1 (1ªHora) al 6 (6ªHora).

    (NOTA: Un profesor no puede tener dos clases el mismo día a la misma hora)

    - ID materia (4 dígitos): Debe coincidir con alguna materia existente.
    - Grupo (10 caracteres máximo): Debe coincidir con algún grupo existente.

  - Eliminar hora de un profesor. Solicita el ID del profesor (ID usuario), el grupo, día y hora el cual desea eliminar del horario de dicho profesor, tras ello, pedirá confirmación.

  - Modificar hora de un profesor. Solicita el ID del profesor (ID usuario) al cual desea modificar su horario. Muestra todas sus clases disponible y permite modificar sus campos.

  - Listar horario de un profesor. Solicita el ID de un profesor (ID usuario) y muestra todo su horario.

##### ***Menú Profesor**

![image-20220418204140526](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418204140526.png)

Se accede al iniciar sesión con un usuario de tipo profesor. Lista el horario de dicho profesor y solicita el grupo y la abreviatura de la materia que desea gestionar en ese momento.

![image-20220418210438250](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418210438250.png)

Una vez hayamos seleccionado la clase deseada podremos listar los alumnos que se encuentren en ella con la opción 1, y acto seguido solicita el ID del alumno al cual desea acceder.

![image-20220418213120917](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418213120917.png)

Se nos presentan distintas opciones:

- Ficha del alumno. Permite modificar la información personal del alumno.

- Calificaciones. Nos da acceso al menú de calificaciones con las siguientes opciones:

  ![image-20220418213456584](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220418213456584.png)

  - Agregar calificaciones. Solicita la información para añadir una nueva calificación al sistema:
    - Fecha de la calificación (xx/yy/zzzz). Deberá escribirse con el formato establecido.
    - Descripción de la calificación (30 caracteres máximo)
    - Nota de la calificación (de 0 a 10)
  - Eliminar calificaciones. Solicita la descripción de la calificación que desea eliminar y pide confirmación para borrarla.
  - Modificar calificaciones. Solicita la descripción de la calificación que desea modificar y permite cambiar la información de sus campos.
  - Listar calificaciones. Muestra todas las calificaciones de la asignatura del alumno.

## Documentación del Sistema

### Módulos Implementados y Subproblemas

- #### Módulo cuaderno

  Es el módulo principal, que relaciona los tres módulos troncales (carga, guarda y perfil) y contiene las instrucciones de inicio de sesión.

- #### Módulo perfil

  Contiene los dos menús de los perfiles que ofrece el programa, el de administrador y profesor.

- #### Módulo carga

  Se encarga de cargar la información de los ficheros de la memoria del ordenador a los registros al iniciar el programa.

- #### Módulo guarda

  Se encarga de guardar la información de los registros a los ficheros del ordenador al terminar de usar el programa.

- #### Módulo administrador

  Está formado por todas las funciones que permiten modificar, crear y eliminar los datos que ya se encuentran en los registros (a excepción de las calificaciones, exclusivo de los profesores).

- #### Módulo profesor

  Está formado por todas las funciones que permiten modificar, crear y eliminar la información de los alumnos y sus calificaciones.

- #### Módulo datos

  Contiene las definiciones de las estructuras que se emplean y las declaraciones de los vectores para uso global.
  
  ### Pruebas de Unidad
  
  #### ·Módulo Cuaderno
  
  - `static void inicio_sesion (int nUsuarios, int *i_us)`
  
    Introducimos distintos usuarios:
  
    Usuario: admin Contraseña: jas12345 -> Funciona Correctamente
  
    Usuario: profe Contraseña:pl123456 -> Funciona Correctamente
  
  - `static int profe_o_admin (int i)`
  
    Si el usuario[i] pertenece a un administrador devuelve 1 -> Funciona Correctamente
  
    Si el usuario[i] pertenece a un profesor devuelve 0 -> Funciona Correctamente
  
  #### ·Módulo Perfil
  
  - `void perfil (tipo,i_usuario)`
  
    Observamos que la función recibe el tipo de perfil del usuario introducido y accede al menú que le corresponde -> Funciona Correctamente
  
  - `static void menu_admin (i)`
  
    Observamos que nos da acceso al menú de administrador tras recibir un usuario de dicho tipo -> Funciona Correctamente
  
    Introducimos los distintos valores del menú para ver si el resultado es el esperado:
  
    1 -> Funciona Correctamente
  
    2 -> Funciona Correctamente
  
    3 -> Funciona Correctamente
  
    4 -> Funciona Correctamente
  
    0 -> Funciona Correctamente
  
  - `static void menu_profe (i_profe)`
  
    Observamos que nos da acceso al menú de profesor tras recibir un usuario (ID:002) de dicho tipo y nos lista su horario, introducimos un grupo: 1HCSA y una materia: MCS, y luego nos permite trabajar con dicha clase -> Funciona Correctamente
  
    Introducimos los distintos valores del menú para ver si el resultado es el esperado:
  
    1 -> Funciona Correctamente
  
    2 -> Funciona Correctamente
  
    0 -> Funciona Correctamente
  
  #### ·Módulo Profesor
  
  - `void list_hor_profe (int i_profe, int nHorarios, int nMaterias)`
  
    Recibe la i correspodiente al profesor introducido y observamos que muestra todo su horario -> Funciona Correctamente
  
  - `void gestor_alumnos (int i_grupo, int nAlumnos)`
  
    Introducimos el ID: 123456 y nos permite acceder su ficha o calificaciones -> Funciona Correctamente
  
    Introducimos los distintos valores del menú para ver si el resultado es el esperado:
  
    1 -> Funciona Correctamente
  
    2 -> Funciona Correctamente
  
    0 -> Funciona Correctamente
  
    3 -> Funciona Correctamente
  
  - `void ficha_alumno (char id[], int nAlumnos)`
  
    Nos muestra la información del alumno introducido ID: 123456, Nombre: Fernando Perez, Dirección: Avda Europa n21, Localidad: Cadiz, Curso: 1 Bach Ciencias Sociales, Grupo: 1HCSA -> Funciona Correctamente
  
    Cambiamos los datos del alumno ID: 121212, Nombre: Fernando Torres, Dirección: Avda Francia n21, Localidad: Cadiz, Curso: 1 Bach Ciencias Sociales, Grupo: 1HCSA -> Funciona Correctamente
  
  - `void menu_calificaciones (char id[], int i_grupo, int nAlumnos, int nCalificaciones)`
  
    Recibe el ID del alumno y nos muestra el menú de calificaciones -> Funciona Correctamente
  
    Introducimos los distintos valores del menú para ver si el resultado es el esperado:
  
    1 -> Funciona Correctamente
  
    2 -> Funciona Correctamente
  
    3 -> Funciona Correctamente
  
    4 -> Funciona Correctamente
  
    0 -> Funciona Correctamente
  
  - `void agregar_calificaciones (char id[], int i_grupo, int *nCalificaciones)`
  
    Introducimos una fecha: 25/03/2022, descripción: Examen unidad 4 y nota: 8. -> Funciona Correctamente
  
    Si escribimos "Si" lo crea-> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo crea-> Funciona Correctamente
  
  - `void eliminar_calificaciones (int *nCalificaciones)`
  
    Introducimos la Descripción: Examen Unidad 4 para eliminar la calificación. Nos pide una confirmación:
  
    Si escribimos "Si" la elimina -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no la elimina -> Funciona Correctamente
  
  - `void modificar_calificaciones (char id[], int i_grupo, int nCalificaciones)`
  
    Muestra las calificaciones del alumno e introducimos la Descripción: Examen Unidad 4 mostrándonos la calificación completa 25/03/2022-Examen unidad 4-0001-123456-8 y nos permite modificarla -> Funciona Correctamente
  
    Modificamos los datos 11/12/2021-Examen unidad 2-0001-123456-3 -> Funciona Correctamente
  
  - `void listar_calificaciones (char id[], int i_grupo, int nCalificaciones)`
  
    Recibe el ID del alumno y observamos que muestra todas sus calificaciones -> Funciona Correctamente
  
  #### ·Módulo Administrador
  
  - `void agregar_usuarios (int *nUsuarios) `
  
    Introducimos un nuevo usuario al sistema, ID: 111, Nombre: Francisco Quevedo, Perfil: profesor, Usuario: queve, Contraseña: francis9 -> Funciona Correctamente
  
    Si escribimos "Si" lo crea-> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo crea-> Funciona Correctamente
  
  - `void eliminar_usuarios (int *nUsuarios)`
  
    Introducimos el ID:111 para eliminar al usuario. Nos pide una confirmación:
  
    Si escribimos "Si" lo elimina -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo elimina -> Funciona Correctamente
  
  - `void modificar_usuarios (int nUsuarios)`
  
    Introducimos el Usuario: profe para modificarlo. 
  
    Aparecen los datos actuales 002-Pilar Lopez-profesor-profe-pl123456 y nos deja elegir que queremos cambiar -> Funciona Correctamente
  
    Los cambiamos 003-Pilar Lopez-profesor-pllop-pl123456 -> Funciona Correctamente
  
  - `void listar_usuarios (int nUsuarios)` 
  
    Elegimos la opción de listar y observamos que aparecen los usuarios del sistema -> Funciona Correctamente.
  
  - `void agregar_alumnos (int *nAlumnos) `
  
    Introducimos un nuevo alumno al sistema, ID: 123456, Nombre: Fernando Perez, Dirección: Avda Europa n21, Localidad: Cadiz, Curso: 1 Bach Ciencias Sociales, Grupo: 1HCSA-> Funciona Correctamente
  
    Si escribimos "Si" lo crea-> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo crea-> Funciona Correctamente
  
  - `void eliminar_alumnos (int *nAlumnos)`
  
    Introducimos el ID:123456 para eliminar al alumno. Nos pide una confirmación:
  
    Si escribimos "Si" lo elimina -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo elimina -> Funciona Correctamente
  
  - `void modificar_alumnos (int nAlumnos)`
  
    Introducimos el ID: 123456 para modificarlo. 
  
    Aparecen los datos actuales 123456-Fernando Perez-Avda Europa n21-Cadiz-1 Bach Ciencias Sociales-1HCSA y nos deja elegir que queremos cambiar -> Funciona Correctamente
  
    Los cambiamos 111333-Fernando Perez-Avda Europa n21-Puerto Real-1 Bach Ciencias Sociales-1HCSA -> Funciona Correctamente
  
  - `void listar_alumnos (int nAlumnos)` 
  
    Elegimos la opción de listar y observamos que aparecen los alumnos del sistema -> Funciona Correctamente
  
  - `void materias_matriculado (int i_alumno, int nMatriculas, int nMaterias)`
  
    Recibe la i del alumno y observamos que muestra su nombre con las materias en las que se encuentra matriculado -> Funciona Correctamente
  
  - `void agregar_matricula (int i_alumno, int nMaterias, int *nMatriculas)`
  
    Introducimos el ID: 0002 de la materia en la que queremos matricular al alumno. Nos pide confirmación:
  
    Si escribimos "Si" la crea -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no la crea -> Funciona Correctamente
  
  - `void eliminar_matricula (int i_alumno, int *nMatriculas)`
  
    Introducimos el ID: 0002 de la materia de la cual queremos desmatricular al alumno. Nos pide confirmación:
  
    Si escribimos "Si" lo desmatricula -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo desmatricula-> Funciona Correctamente
  
  - `void modificar_matricula (int i_alumno, int nMatriculas)`
  
    Introducimos el ID: 0002 de la materia la cual queremos cambiar la matrícula y nos pide que introduzcamos el ID: 0003 de otra materia -> Funciona Correctamente
  
  - `void agregar_materias (int *nMaterias)`
  
    Introducimos una nueva materia al sistema, ID: 0003, Nombre: Fisica y Quimica, Abreviatura: FYQ   -> Funciona Correctamente
  
    Si escribimos "Si" la crea-> Funciona Correctamente
  
    Si escribimos distinto de "Si" no la crea-> Funciona Correctamente
  
  - `void eliminar_materias (int *nMaterias)`
  
    Introducimos el ID: 0003 para eliminar la materia. Nos pide una confirmación:
  
    Si escribimos "Si" la elimina -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no la elimina -> Funciona Correctamente
  
  - `void modificar_materias (int nMaterias)`
  
    Introducimos el ID: 0003 para modificarla. 
  
    Aparecen los datos actuales 0003-Fisica y Quimica-FYQ y nos deja elegir que queremos cambiar -> Funciona Correctamente
  
    Los cambiamos 3000-Fisica y Quimica-FyQ -> Funciona Correctamente
  
  - `void listar_materias (int nMaterias)`
  
    Elegimos la opción de listar y observamos que aparecen las materias guardadas en el sistema -> Funciona Correctamente
  
  - `void agregar_horarios (int *nHorarios, int nUsuarios, int nMaterias, int nAlumnos)`
  
    Introducimos el ID: 1111 del profesor al que queremos añadir un horario.
  
    Añadimos un nuevo horario al profesor introducido, Día: 1, Hora: 1, ID Materia: 0004, Grupo: 1HCSA -> Funciona Correctamente
  
    Si escribimos "Si" lo crea-> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo crea-> Funciona Correctamente
  
  - `void eliminar_horarios (int *nHorarios, int nUsuarios)`
  
    Introducimos el ID: 1111 del profesor al que queremos eliminar un horario.
  
    Introducimos Grupo: 1HCSA, Hora: 1 y Día: 1para eliminar el horarios. Nos pide confirmación:
  
    Si escribimos "Si" lo elimina -> Funciona Correctamente
  
    Si escribimos distinto de "Si" no lo elimina -> Funciona Correctamente
  
  - `void modificar_horarios (int nUsuarios, int nHorarios)`
  
    Introducimos el ID: 1111 del profesor al que queremos modificar el horario.
  
    Observamos que muestra el nombre del profesor y sus horarios -> Funciona Correctamente
  
    Cambiamos un horario que coincida con el del profesor 111-3-5-0004-1HCSA -> Funciona Correctamente
  
  - `int auxiliar_horarios (char id[4], int nHorarios, int *q)`
  
    Recibe el ID del profesor e introducimos Materia: 0004 y Grupo: 1HCSA y nos dice que el profesor tiene esa clase -> Funciona Correctamente
  
  - `void listar_horarios (int nUsuarios, int nHorarios)`
  
    Introducimos el ID: 002 del profesor y observamos que nos muestra todos  su horarios -> Funciona Correctamente
  
  ### Pruebas del Conjunto de Rutas Básicas (Caja Blanca)
  
  #### Módulo profesor 
  
  ```
  void list_hor_profe (int i_profe, int nHorarios, int nMaterias) {
  	
  	int i, j; //1
  	
  	printf("\nHORARIO: "); //1
  	printf("\nDIA-HORA-MATERIA-GRUPO\n"); //1
  	
  	for (i=0;i<nHorarios;i++) { //2
  		
  		if (strcmp(v_horarios[i].Id_profesor, v_usuarios[i_profe].Id_usuario)==0) {//3
  			
  			for (j=0;j<nMaterias;j++) { //4
  				
  				if(strcmp(v_materias[j].Id_materias, v_horarios[i].Id_materia)==0){//5
  					printf("%d-%d-%s-%s\n", v_horarios[i].Dia_clase, v_horarios[i].Hora_clase, v_materias[j].Abrev_materia, v_horarios[i].Grupo);//6
  				}
  				//7
  			}
  			 //8
  		}
  		//9
  	}	
  	
  } //10
  ```
  
  ***1-CFG***

![](C:\Users\jumah\AppData\Roaming\Typora\typora-user-images\image-20220417191821156.png)

***2-Complejidad Ciclomática***

V(G)= NA-NN+2 = NNP+1 = nº Regiones

V(G)= 13-10+2 = 4+1 = 5
La complejidad ciclomática es de 5. 

***3-Conjunto Básico de Rutas Linealmente Independientes***

1º Ruta: 1-2-10

2º Ruta: 1-2-3-9-2-10

3º Ruta: 1-2-3-4-8-9-2-10

4º Ruta: 1-2-3-4-5-7-4-8-9-2-10

5º Ruta: 1-2-3-4-5-6-7-4-8-9-2-10

El resto de rutas son combinaciones de estas cinco.

***4-Casos de Prueba para Forzar la Ejecución de la Ruta del Conjunto Básico***

Si i<nHorarios es falso el bucle no se ejecuta y acaba la función. Si i<nHorarios es verdadero entonces escribirá el horario del profesor si i<nMaterias y se encuentra una materia que coincida con la condición impuesta.
